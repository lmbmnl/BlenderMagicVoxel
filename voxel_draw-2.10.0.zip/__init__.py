# SPDX-License-Identifier: MIT
# BlenderMagicVoxel by lmbmnl - https://github.com/lmbmnl/BlenderMagicVoxel
# MagicaVoxel-style voxel editor for Blender 5.x (sidebar: Start Voxel / Clear / Confirm).
# Inspired by VoxelDraw by Sreeraj R (2020, MIT): https://github.com/theunnecessarythings/VoxelDraw
#
# Data model: the drawing is a dict {integer grid cell: palette index 1..255}
# stored on the object (custom props "_vd_*"), MagicaVoxel style. The mesh is
# regenerated from it (numpy), so it is always a single welded body with no
# hidden faces, and editing keeps working across mode switches (Edit Mode =
# drawing, Object Mode = paused) and save/load, until "Confirm". Undo/redo are
# handled by the tool itself (delta history). Selection, move, rotate and flip
# work on whole cells, so everything always stays on the voxel grid.

import colorsys
import json
import struct
import time
import traceback
from functools import lru_cache
from itertools import product
from math import atan2, ceil, cos, floor, inf, pi, sin

import blf
import bmesh
import bpy
import gpu
import numpy as np
from bpy.app.handlers import persistent
from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy_extras.view3d_utils import (location_3d_to_region_2d, region_2d_to_origin_3d,
                                     region_2d_to_vector_3d)
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from types import SimpleNamespace

from . import vd_ui

# ---------------------------------------------------------------- pure logic start
AXIS_ITEMS = [
    ("XY", "XY", "Floor plane XY (normal Z)"),
    ("YZ", "YZ", "Floor plane YZ (normal X)"),
    ("XZ", "XZ", "Floor plane XZ (normal Y)"),
]
AXIS_INDEX = {"XY": 2, "YZ": 0, "XZ": 1}  # index of the plane normal
MODE_ITEMS = [
    ("ATTACH", "Attach", "Add voxels with the active colour (1)"),
    ("ERASE", "Erase", "Remove voxels (2)"),
    ("MOVE", "Move", "Move the selected voxels with the gizmo, snapped to the grid (3)"),
    ("PAINT", "Paint", "Recolour existing voxels (4)"),
    ("SELECT", "Select", "Select voxels to move / rotate / flip / copy (5)"),
]
MOVE_AXIS_ITEMS = [
    ("FREE", "Free", "Drag moves on the plane facing the view"),
    ("X", "X", "Drag moves along X (X key)"),
    ("Y", "Y", "Drag moves along Y (Y key)"),
    ("Z", "Z", "Drag moves along Z (Z key)"),
]
BRUSH_ITEMS = [
    ("SHAPE", "Shape", "Stamp the brush shape, drag to paint"),
    ("BOX", "Box", "Drag a rectangle on the plane of the first voxel"),
    ("LINE", "Line", "Drag a line on the plane of the first voxel"),
    ("FACE", "Face", "Whole flat face region: extrude / remove / paint it"),
    ("FILL", "Fill", "Connected voxels of the same colour: recolour / remove them"),
]
SHAPE_ITEMS = [
    ("POINT", "Point", "Filled n x n square"),
    ("SQUARE", "Square", "Square"),
    ("TRIANGLE", "Triangle", "Triangle"),
    ("HEXAGON", "Hexagon", "Hexagon"),
    ("CIRCLE", "Circle", "Circle"),
    ("SPHERE", "Sphere", "Sphere (3D, size up to 64)"),
]
COLOR_ATTR = "vd_color"
TMP_MESH = ".vd_tmp"
N4 = ((1, 0), (-1, 0), (0, 1), (0, -1))
N6 = ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))

# (neighbour offset, quad corners CCW seen from outside). Cell (i,j,k) occupies
# the lattice box [i,i+1]x[j,j+1]x[k,k+1]; world = lattice * size, like
# MagicaVoxel (voxels sit ON the floor plane). Index // 2 = axis.
FACES = (
    ((1, 0, 0), ((1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1))),
    ((-1, 0, 0), ((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0))),
    ((0, 1, 0), ((0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0))),
    ((0, -1, 0), ((0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1))),
    ((0, 0, 1), ((0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1))),
    ((0, 0, -1), ((0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0))),
)

_B, _OFF = 1 << 21, 1 << 20  # int64 cell keys; coordinates are capped at +-100000


def _keys(p):
    p = p + _OFF
    return (p[:, 0] * _B + p[:, 1]) * _B + p[:, 2]


def default_palette():
    """MagicaVoxel default palette as sRGB floats; index 0 = empty."""
    steps = (0xff, 0xcc, 0x99, 0x66, 0x33, 0x00)
    ramp = (0xee, 0xdd, 0xbb, 0xaa, 0x88, 0x77, 0x55, 0x44, 0x22, 0x11)
    cols = [(0, 0, 0)]
    cols += [(r, g, b) for r in steps for g in steps for b in steps][:-1]
    cols += [(v, 0, 0) for v in ramp] + [(0, v, 0) for v in ramp]
    cols += [(0, 0, v) for v in ramp] + [(v, v, v) for v in ramp]
    return [(r / 255, g / 255, b / 255) for r, g, b in cols]


def exposed_faces(cells):
    """Per FACES direction: (cells (n,3), colours (n,)) whose face there is visible."""
    pos = np.array(list(cells), np.int64).reshape(-1, 3)
    col = np.fromiter(cells.values(), np.int64, len(cells))
    sk = np.sort(_keys(pos))
    out = []
    for normal, _quad in FACES:
        nk = _keys(pos + normal)
        idx = np.minimum(np.searchsorted(sk, nk), len(sk) - 1)
        m = sk[idx] != nk
        out.append((pos[m], col[m]))
    return out


def greedy_rects(pos, col, axis):
    """Merge coplanar same-colour faces of one direction into rectangles.
    Returns (lowest cells (n,3), extents (n,3), colours (n,))."""
    b, c = [n for n in range(3) if n != axis]
    left = {(p[axis], p[b], p[c]): k for p, k in zip(pos.tolist(), col.tolist())}
    lows, exts, cols = [], [], []
    for key in sorted(left):
        k = left.get(key)
        if k is None:  # already merged into a rectangle
            continue
        lay, u, v = key
        h = 1
        while left.get((lay, u, v + h)) == k:
            h += 1
        w = 1
        while all(left.get((lay, u + w, v + t)) == k for t in range(h)):
            w += 1
        for du in range(w):
            for dv in range(h):
                del left[(lay, u + du, v + dv)]
        low, ext = [0, 0, 0], [1, 1, 1]
        low[axis], low[b], low[c] = lay, u, v
        ext[b], ext[c] = w, h
        lows.append(low)
        exts.append(ext)
        cols.append(k)
    return (np.array(lows, np.int64).reshape(-1, 3),
            np.array(exts, np.int64).reshape(-1, 3), np.array(cols, np.int64))


def build_geometry(cells, size, greedy=False):
    """Welded surface of the voxel dict: (verts (m,3), quads (f,4), face colours (f,)).
    greedy=True merges same-colour coplanar faces (leaves T-junctions)."""
    if not cells:
        return np.zeros((0, 3), np.float32), np.zeros((0, 4), np.int64), np.zeros(0, np.int64)
    corners, cols = [], []
    for n, ((_normal, quad), (pos, col)) in enumerate(zip(FACES, exposed_faces(cells))):
        ext = np.ones_like(pos)
        if greedy:
            pos, ext, col = greedy_rects(pos, col, n // 2)
        corners.append(pos[:, None, :] + np.array(quad) * ext[:, None, :])
        cols.append(col)
    corners = np.concatenate(corners).reshape(-1, 3)
    _, first, inv = np.unique(_keys(corners), return_index=True, return_inverse=True)
    verts = (corners[first] * size).astype(np.float32)
    return verts, inv.reshape(-1, 4), np.concatenate(cols)


def ghost_geometry(cells, inflate=0.02):
    """Brush ghost in lattice units: (triangles (3t,3) of its outer faces pushed out by
    `inflate` so they never z-fight the voxels they cover, unique edges (2e,3) of
    those faces). Inner faces / edges between ghost voxels are left out."""
    tris, quads = [], []
    for (normal, quad), (pos, _col) in zip(FACES, exposed_faces(dict.fromkeys(cells, 1))):
        q = pos[:, None, :] + np.array(quad)
        quads.append(q)
        tris.append((q + np.array(normal) * inflate)[:, (0, 1, 2, 0, 2, 3)])
    seg = np.concatenate(quads)[:, ((0, 1), (1, 2), (2, 3), (3, 0))].reshape(-1, 2, 3)
    k = _keys(seg.reshape(-1, 3)).reshape(-1, 2)
    _, first = np.unique(np.sort(k, axis=1), axis=0, return_index=True)
    return (np.concatenate(tris).reshape(-1, 3).astype(np.float32),
            seg[np.sort(first)].reshape(-1, 3).astype(np.float32))


def mirror_planes(vs, bnds):
    """Live mirror planes as quads (4 corners, lattice units) + axis: [(axis, corners)].
    They span the size limit box, or the model bounds plus a margin."""
    sums = mirror_sums(vs)
    if vs.use_limit:
        lo, hi = (0, 0, 0), tuple(vs.model_size)
    else:
        lo, hi = bnds or ((0, 0, 0), (0, 0, 0))
        lo = [min(lo[i], 0) - 2 for i in range(3)]
        hi = [max(hi[i], 0) + 3 for i in range(3)]
    out = []
    for a in live_mirror_axes(vs):
        b, c = [i for i in range(3) if i != a]
        corners = []
        for u, v in ((lo[b], lo[c]), (hi[b], lo[c]), (hi[b], hi[c]), (lo[b], hi[c])):
            p = [0.0, 0.0, 0.0]
            p[a], p[b], p[c] = (sums[a] + 1) / 2, u, v
            corners.append(p)
        out.append((a, corners))
    return out


def _outline(pts, dirs):
    return {p for p in pts
            if any(tuple(p[i] + d[i] for i in range(len(p))) not in pts for d in dirs)}


@lru_cache(maxsize=64)
def shape_offsets(shape, n, rot, fill=False):
    """2D brush cells (u, v) centred on (0, 0), rotated rot x 90 deg clockwise.
    n = side length in cells. Slanted sides are 45 deg pixel steps, so every
    size is symmetric: triangle base 2n-1 / height n, hexagon width 3n-2 / height 2n-1.
    fill=False keeps only the outline (Point is always filled)."""
    m = n - 1
    if shape in ('POINT', 'SQUARE'):
        pts = {(u, v) for u in range(n) for v in range(n)}
    elif shape == 'CIRCLE':
        r2 = (n * n - n) / 4
        pts = {(u, v) for u in range(n) for v in range(n)
               if (u - m / 2) ** 2 + (v - m / 2) ** 2 <= r2}
    else:
        if shape == 'TRIANGLE':  # row v spans u in [a, b]
            rows = [(v, 2 * m - v) for v in range(n)]
        else:
            rows = [(abs(v - m), 3 * m - abs(v - m)) for v in range(2 * m + 1)]
        pts = {(u, v) for v, (a, b) in enumerate(rows) for u in range(a, b + 1)}
    if shape != 'POINT' and not fill:
        pts = _outline(pts, N4)
    for _ in range(rot % 4):
        pts = {(v, -u) for u, v in pts}
    us, vs = zip(*pts)
    cu, cv = (min(us) + max(us)) // 2, (min(vs) + max(vs)) // 2
    return frozenset((u - cu, v - cv) for u, v in pts)


@lru_cache(maxsize=16)
def sphere_offsets(n, fill=False):
    m = n - 1
    r2 = (n * n - n) / 4
    pts = {(x, y, z) for x, y, z in product(range(n), repeat=3)
           if (x - m / 2) ** 2 + (y - m / 2) ** 2 + (z - m / 2) ** 2 <= r2}
    if not fill:
        pts = _outline(pts, N6)
    h = m // 2
    return frozenset((x - h, y - h, z - h) for x, y, z in pts)


def stamp_cells(cell, axis, shape, n, rot, fill=False):
    """Brush cells centred on `cell`, lying in the plane with normal `axis`."""
    if shape == 'SPHERE':  # ponytail: capped at 64, a python-built ball is O(n^3)
        return [(cell[0] + x, cell[1] + y, cell[2] + z) for x, y, z in sphere_offsets(min(n, 64), fill)]
    b, c = [i for i in range(3) if i != axis]
    out = []
    for u, v in shape_offsets(shape, n, rot, fill):
        p = list(cell)
        p[b] += u
        p[c] += v
        out.append(tuple(p))
    return out


def mirror_cell(c, axis, s=0):
    """Mirror cell i to s - i. s = 0: plane through the middle of voxel (0,0,0), the
    first voxel spawned on the 3D cursor; s = size - 1: centre of a 0..size model."""
    return tuple(s - c[i] if i == axis else c[i] for i in range(3))


def mirror_cells(cells, axes, sums=(0, 0, 0)):
    out = set(cells)
    for a in axes:
        out |= {mirror_cell(c, a, sums[a]) for c in out}
    return list(out)


def live_mirror_axes(vs):
    return [i for i, on in enumerate(vs.mirror) if on] if vs.mirror_live else []


def mirrored(vs, cells):
    """Brush cells plus their live-mirror copies."""
    axes = live_mirror_axes(vs)
    return mirror_cells(cells, axes, mirror_sums(vs)) if axes else cells


def mirror_sums(vs):
    """Per-axis s of mirror_cell: the model centre when the size limit is on (the
    first voxel would sit on the limit edge), else the first voxel."""
    return tuple(n - 1 for n in vs.model_size) if vs.use_limit else (0, 0, 0)


def ray_axis_param(o, d, c, axis):
    """Parameter s of the point c + s*e_axis closest to the ray o + t*d (None if parallel)."""
    w = [c[i] - o[i] for i in range(3)]
    b, cc = d[axis], sum(x * x for x in d)
    den = cc - b * b
    if den < 1e-9 * cc:
        return None
    return (b * sum(d[i] * w[i] for i in range(3)) - cc * w[axis]) / den


def seg_dist(p, a, b):
    """2D distance from point p to segment ab."""
    ab = (b[0] - a[0], b[1] - a[1])
    L = ab[0] ** 2 + ab[1] ** 2
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * ab[0] + (p[1] - a[1]) * ab[1]) / L))
    return ((p[0] - a[0] - t * ab[0]) ** 2 + (p[1] - a[1] - t * ab[1]) ** 2) ** 0.5


def line_cells(a, b):
    n = max(abs(b[i] - a[i]) for i in range(3))
    if n == 0:
        return [tuple(a)]
    return [tuple(a[i] + floor((b[i] - a[i]) * s / n + 0.5) for i in range(3)) for s in range(n + 1)]


def box_cells(a, b, axis, fill=True):
    """Rectangle between a and b (same layer along `axis`); fill=False = border only."""
    lo = [min(a[i], b[i]) for i in range(3)]
    hi = [max(a[i], b[i]) for i in range(3)]
    p, q = [i for i in range(3) if i != axis]
    return [c for c in product(*(range(lo[i], hi[i] + 1) for i in range(3)))
            if fill or c[p] in (lo[p], hi[p]) or c[q] in (lo[q], hi[q])]


def flood(cells, start, same_color=False):
    """6-connected voxels reachable from start (optionally only the same colour)."""
    col = cells[start]
    seen, stack = {start}, [start]
    while stack:
        x, y, z = stack.pop()
        for q in ((x + 1, y, z), (x - 1, y, z), (x, y + 1, z), (x, y - 1, z), (x, y, z + 1), (x, y, z - 1)):
            if q not in seen and q in cells and (not same_color or cells[q] == col):
                seen.add(q)
                stack.append(q)
    return seen


def face_region(cells, start, normal, limit=65536):
    """Voxels of the flat, exposed face region containing start (MagicaVoxel Face brush)."""
    a = [abs(v) for v in normal].index(1)
    b, c = [i for i in range(3) if i != a]
    seen, stack = {start}, [start]
    while stack and len(seen) < limit:
        p = stack.pop()
        for db, dc in N4:
            q = list(p)
            q[b] += db
            q[c] += dc
            q = tuple(q)
            if q in seen or q not in cells:
                continue
            if (q[0] + normal[0], q[1] + normal[1], q[2] + normal[2]) in cells:
                continue  # covered: not part of the visible face
            seen.add(q)
            stack.append(q)
    return seen


def rotate_fn(sel, axis, ccw):
    """90 deg rotation around `axis` (right-hand ccw), kept centred on the selection.
    Odd/even sides can't share an exact centre: the half-voxel is rounded toward
    zero, so rotating back (or 4 times) returns exactly to the start."""
    b, c = (axis + 1) % 3, (axis + 2) % 3

    def raw(cell):
        p = list(cell)
        p[b], p[c] = (-cell[c], cell[b]) if ccw else (cell[c], -cell[b])
        return p
    lo, hi = bounds_of(sel)
    rlo, rhi = bounds_of({tuple(raw(s)) for s in (lo, hi)})  # rotated box corners
    off = [lo[i] + int(((hi[i] - lo[i]) - (rhi[i] - rlo[i])) / 2) - rlo[i] for i in range(3)]
    return lambda cell: tuple(v + off[i] for i, v in enumerate(raw(cell)))


def flip_fn(sel, axis):
    lo, hi = bounds_of(sel)
    return lambda c: tuple(lo[i] + hi[i] - c[i] if i == axis else c[i] for i in range(3))


def rotate_cells(cells, axis, steps):
    """{cell: colour} rotated by steps x 45 deg (right hand around axis) about the
    centre of its bounding box. Multiples of 90 deg are exact (rotate_fn); odd steps
    can't stay on the grid: every target voxel takes the source voxel under its
    centre (nearest), so the shape is approximated."""
    steps %= 8
    if not cells or steps == 0:
        return dict(cells)
    if steps % 2 == 0:
        cur = dict(cells)
        for _ in range(1 if steps == 6 else steps // 2):  # 270 deg = one clockwise turn
            fn = rotate_fn(set(cur), axis, steps != 6)
            cur = {fn(c): k for c, k in cur.items()}
        return cur
    b, c = (axis + 1) % 3, (axis + 2) % 3
    lo, hi = bounds_of(cells)
    cb, cc = (lo[b] + hi[b] + 1) / 2, (lo[c] + hi[c] + 1) / 2
    hb, hc = (hi[b] - lo[b] + 1) / 2, (hi[c] - lo[c] + 1) / 2
    co, si = cos(steps * pi / 4), sin(steps * pi / 4)
    rb, rc = abs(co) * hb + abs(si) * hc, abs(si) * hb + abs(co) * hc  # rotated half extents
    ta, tb, tc = np.meshgrid(np.arange(lo[axis], hi[axis] + 1),
                             np.arange(floor(cb - rb), ceil(cb + rb)),
                             np.arange(floor(cc - rc), ceil(cc + rc)), indexing='ij')
    u, v = tb.ravel() + 0.5 - cb, tc.ravel() + 0.5 - cc
    dst = np.empty((u.size, 3), np.int64)
    dst[:, axis], dst[:, b], dst[:, c] = ta.ravel(), tb.ravel(), tc.ravel()
    src = dst.copy()
    src[:, b] = np.floor(cb + co * u + si * v)  # inverse rotation of the target centre
    src[:, c] = np.floor(cc - si * u + co * v)
    pos = np.array(list(cells), np.int64)
    col = np.fromiter(cells.values(), np.int64, len(cells))
    keys = _keys(pos)
    order = np.argsort(keys)
    sk = keys[order]
    k = _keys(src)
    idx = np.minimum(np.searchsorted(sk, k), len(sk) - 1)
    hit = sk[idx] == k
    return {tuple(p): v for p, v in zip(dst[hit].tolist(), col[order][idx[hit]].tolist())}


def wrap_angle(a):
    """Angle in (-pi, pi]."""
    return a - 2 * pi * ceil((a - pi) / (2 * pi))


def transform(cells, sel, fn, keep=False):
    """Move the selected voxels through fn (overwriting what is there).
    Returns ({cell: [old, new]}, new selection)."""
    moved = {fn(c): cells[c] for c in sel}
    new = {} if keep else {c: 0 for c in sel}
    new.update(moved)
    return {c: [cells.get(c, 0), k] for c, k in new.items() if cells.get(c, 0) != k}, set(moved)


def cells_in_rect(cells, mvp, size, width, height, rect):
    """Voxels whose centre projects inside the screen rectangle (region pixels)."""
    if not cells:
        return set()
    keys = list(cells)
    p = (np.array(keys, np.float64) + 0.5) * size
    h = np.c_[p, np.ones(len(p))] @ np.array(mvp, np.float64).T
    w = h[:, 3]
    ok = w > 1e-6
    w = np.where(ok, w, 1)
    x = (h[:, 0] / w + 1) * width / 2
    y = (h[:, 1] / w + 1) * height / 2
    x0, x1 = sorted((rect[0], rect[2]))
    y0, y1 = sorted((rect[1], rect[3]))
    inside = ok & (x >= x0) & (x <= x1) & (y >= y0) & (y <= y1)
    return {k for k, f in zip(keys, inside.tolist()) if f}


def vox_bytes(cells, pal):
    """MagicaVoxel .vox (one model, shifted to start at 0) from cells + (256,3) sRGB palette."""
    lo, hi = bounds_of(cells)
    dims = [hi[i] - lo[i] + 1 for i in range(3)]
    if max(dims) > 256:
        raise ValueError(f"Model is {dims[0]}x{dims[1]}x{dims[2]}: .vox allows 256 per axis")
    v = np.array([(x - lo[0], y - lo[1], z - lo[2], k) for (x, y, z), k in cells.items()], np.uint8)
    rgba = np.full((256, 4), 255, np.uint8)
    rgba[:255, :3] = np.clip(np.round(np.asarray(pal)[1:] * 255), 0, 255)  # file entry i = index i+1

    def chunk(cid, content, children=b""):
        return cid + struct.pack("<ii", len(content), len(children)) + content + children
    body = (chunk(b"SIZE", struct.pack("<3i", *dims))
            + chunk(b"XYZI", struct.pack("<i", len(v)) + v.tobytes())
            + chunk(b"RGBA", rgba.tobytes()))
    return b"VOX " + struct.pack("<i", 150) + chunk(b"MAIN", b"", body)


def _read_str(b, p):
    n, = struct.unpack_from("<i", b, p)
    return b[p + 4:p + 4 + n].decode("utf-8", "replace"), p + 4 + n


def _read_dict(b, p):
    n, = struct.unpack_from("<i", b, p)
    p += 4
    d = {}
    for _ in range(n):
        k, p = _read_str(b, p)
        d[k], p = _read_str(b, p)
    return d, p


def _vox_rot(r):
    i0, i1 = r & 3, (r >> 2) & 3
    m = np.zeros((3, 3), np.int64)
    for row, (i, bit) in enumerate(((i0, 16), (i1, 32), (3 - i0 - i1, 64))):
        m[row, i] = -1 if r & bit else 1
    return m


def read_vox(data):
    """-> (cells shifted to start at 0, palette list[256] or None). Merges every
    model of the scene graph with its translation/rotation. Any damage in the
    file raises ValueError."""
    if data[:4] != b"VOX ":
        raise ValueError("Not a MagicaVoxel .vox file")
    try:
        return _read_vox(data)
    except (struct.error, IndexError, KeyError, ValueError, RecursionError) as e:
        raise ValueError(f"Damaged .vox file: {e}") from e


def _read_vox(data):
    if data[8:12] != b"MAIN":
        raise ValueError("no MAIN chunk")
    p, size, models, nodes, rgba = 8, (0, 0, 0), [], {}, None
    while p + 12 <= len(data):
        cid = data[p:p + 4]
        n, m = struct.unpack_from("<ii", data, p + 4)
        c = p + 12
        if n < 0 or m < 0 or c + n + m > len(data):
            raise ValueError(f"chunk {cid!r} is truncated")
        if cid == b"SIZE":
            size = struct.unpack_from("<3i", data, c)
        elif cid == b"XYZI":
            k, = struct.unpack_from("<i", data, c)
            v = np.frombuffer(data, np.uint8, k * 4, c + 4).reshape(-1, 4).astype(np.int64)
            models.append((size, v))
        elif cid == b"RGBA":
            rgba = np.frombuffer(data, np.uint8, 1024, c).reshape(256, 4)
        elif cid in (b"nTRN", b"nGRP", b"nSHP"):
            nid, = struct.unpack_from("<i", data, c)
            _, q = _read_dict(data, c + 4)
            if cid == b"nTRN":
                child, _res, _layer, nf = struct.unpack_from("<4i", data, q)
                nodes[nid] = ("T", child, _read_dict(data, q + 16)[0] if nf else {})
            elif cid == b"nGRP":
                k, = struct.unpack_from("<i", data, q)
                nodes[nid] = ("G", struct.unpack_from(f"<{k}i", data, q + 4))
            else:
                k, = struct.unpack_from("<i", data, q)
                q, ids = q + 4, []
                for _ in range(k):
                    mid, = struct.unpack_from("<i", data, q)
                    _, q = _read_dict(data, q + 4)
                    ids.append(mid)
                nodes[nid] = ("S", ids)
        p = c + n if cid == b"MAIN" else c + n + m

    placed = []

    def walk(nid, rot, t, path):
        node = nodes.get(nid)
        if node is None:
            return
        if nid in path:
            raise ValueError("the scene graph has a loop")
        path = path | {nid}
        if node[0] == "T":
            fr = node[2]
            r = _vox_rot(int(fr["_r"])) if "_r" in fr else np.eye(3, dtype=np.int64)
            tn = np.array([int(x) for x in fr["_t"].split()], np.int64) if "_t" in fr else np.zeros(3, np.int64)
            if tn.shape != (3,):
                raise ValueError("bad translation")
            walk(node[1], rot @ r, rot @ tn + t, path)
        elif node[0] == "G":
            for ch in node[1]:
                walk(ch, rot, t, path)
        else:
            for mid in node[1]:
                if not 0 <= mid < len(models):
                    raise ValueError(f"shape refers to missing model {mid}")
                (sx, sy, sz), v = models[mid]
                # ponytail: pivot = size // 2; rotated even-sized models may land 1 voxel off
                placed.append(((v[:, :3] - (sx // 2, sy // 2, sz // 2)) @ rot.T + t, v[:, 3]))
    if nodes:
        walk(0, np.eye(3, dtype=np.int64), np.zeros(3, np.int64), frozenset())
    else:
        placed = [(v[:, :3], v[:, 3]) for _, v in models]
    cells = {}
    if sum(len(b) for _, b in placed):
        pos = np.concatenate([a for a, _ in placed])
        col = np.concatenate([b for _, b in placed])
        pos -= pos.min(0)
        cells = {tuple(c): k for c, k in zip(pos.tolist(), col.tolist()) if k}
    pal = None
    if rgba is not None:
        pal = [(0.0, 0.0, 0.0)] + [tuple(x / 255 for x in rgba[i, :3]) for i in range(255)]
    return cells, pal


def bounds_of(cells):
    if not cells:
        return None
    xs, ys, zs = zip(*cells)
    return (min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs))


def grow(bnds, c):
    if bnds is None:
        return c, c
    lo, hi = bnds
    return (tuple(min(lo[n], c[n]) for n in range(3)),
            tuple(max(hi[n], c[n]) for n in range(3)))


def raycast_cells(o, d, cells, bnds, size):
    """Grid DDA. Ray in object-local space. Returns (cell, outward_normal) or None."""
    bmin, bmax = bnds
    p = [o[n] / size for n in range(3)]
    dd = [d[n] / size for n in range(3)]

    # clip the ray against the cells' bounding box (slab test)
    tmin, tmax, entry = 0.0, inf, None
    for n in range(3):
        lo, hi = bmin[n], bmax[n] + 1
        if abs(dd[n]) < 1e-12:
            if p[n] < lo or p[n] > hi:
                return None
            continue
        t1, t2 = (lo - p[n]) / dd[n], (hi - p[n]) / dd[n]
        if t1 > t2:
            t1, t2 = t2, t1
        if t1 > tmin:
            tmin, entry = t1, n
        tmax = min(tmax, t2)
    if tmin > tmax:
        return None

    t = tmin + 1e-7
    start = [p[n] + dd[n] * t for n in range(3)]
    cell = [floor(s) for s in start]
    step = [1 if dd[n] > 0 else -1 for n in range(3)]
    tnext, tdelta = [inf] * 3, [inf] * 3
    for n in range(3):
        if abs(dd[n]) < 1e-12:
            continue
        boundary = cell[n] + (1 if step[n] > 0 else 0)
        tnext[n] = t + (boundary - start[n]) / dd[n]
        tdelta[n] = step[n] / dd[n]

    axis = entry if entry is not None else max(range(3), key=lambda n: abs(dd[n]))
    for _ in range(sum(bmax[n] - bmin[n] + 1 for n in range(3)) + 6):
        key = (cell[0], cell[1], cell[2])
        if key in cells:
            normal = [0, 0, 0]
            normal[axis] = -step[axis]
            return key, tuple(normal)
        n = tnext.index(min(tnext))
        if tnext[n] > tmax:
            return None
        cell[n] += step[n]
        tnext[n] += tdelta[n]
        axis = n
    return None


def pick_cell(o, d, cells, bnds, size, axis, offset, existing):
    """(cell, plane normal axis) under the ray, or None. existing=True targets the
    hit voxel (erase/paint), else the empty cell in front of it; falls back to
    the floor plane (voxels sit on top of it)."""
    if cells and bnds:
        hit = raycast_cells(o, d, cells, bnds, size)
        if hit:
            c, n = hit
            ax = [abs(v) for v in n].index(1)
            return (c if existing else (c[0] + n[0], c[1] + n[1], c[2] + n[2])), ax
    if existing or abs(d[axis]) < 1e-9:
        return None
    t = (offset - o[axis]) / d[axis]
    if t < 0:
        return None
    cell = [floor((o[i] + d[i] * t) / size) for i in range(3)]
    cell[axis] = floor(offset / size + 1e-6)
    if any(abs(c) > 100000 for c in cell):
        return None
    return tuple(cell), axis


# Blender's proportional editing falloffs, as in its transform code: f = 1 - distance / radius
FALLOFF = {
    'SMOOTH': lambda f: 3 * f * f - 2 * f * f * f,
    'SPHERE': lambda f: max(0.0, 2 * f - f * f) ** 0.5,
    'ROOT': lambda f: max(0.0, f) ** 0.5,
    'INVERSE_SQUARE': lambda f: f * (2 - f),
    'SHARP': lambda f: f * f,
    'LINEAR': lambda f: f,
    'CONSTANT': lambda f: 1.0,
}


def _hash01(cell, seed):
    """Stable pseudo random 0..1 per cell (Random falloff: same result every redraw)."""
    h = (cell[0] * 73856093) ^ (cell[1] * 19349663) ^ (cell[2] * 83492791) ^ (seed * 2654435761)
    h &= 0xffffffff
    h = ((h ^ (h >> 16)) * 0x45d9f3b) & 0xffffffff
    return ((h ^ (h >> 16)) & 0xffffff) / 0xffffff


def falloff_weight(kind, f, cell=(0, 0, 0), seed=0):
    if kind == 'RANDOM':
        return _hash01(cell, seed) * f
    return FALLOFF.get(kind, FALLOFF['SMOOTH'])(f)


def proportional_weights(cells, sel, radius, kind, connected=False, view=None, seed=0):
    """{cell: weight} of the unselected voxels within `radius` (in voxels) of the
    selection, like Blender's proportional editing: straight distance to the
    nearest selected voxel (measured on the view plane when `view`, the view
    direction, is given: Projected), or steps through touching voxels (Connected)."""
    sel = {c for c in sel if c in cells}
    if not sel or radius <= 0:
        return {}
    dist = {}
    if connected:
        frontier, step = list(sel), 0
        seen = set(sel)
        while frontier and step + 1 <= radius:
            step += 1
            nxt = []
            for x, y, z in frontier:
                for q in ((x + 1, y, z), (x - 1, y, z), (x, y + 1, z), (x, y - 1, z), (x, y, z + 1), (x, y, z - 1)):
                    if q in cells and q not in seen:
                        seen.add(q)
                        dist[q] = step
                        nxt.append(q)
            frontier = nxt
    else:
        from mathutils import Vector as V, kdtree
        n = V(view).normalized() if view is not None else None

        def flat(c):
            p = V(c)
            return p - n * p.dot(n) if n is not None else p
        tree = kdtree.KDTree(len(sel))
        for i, c in enumerate(sel):
            tree.insert(flat(c), i)
        tree.balance()
        lo, hi = bounds_of(sel)
        r = ceil(radius)
        for c in cells:
            if c in sel or (n is None and not all(lo[i] - r <= c[i] <= hi[i] + r for i in range(3))):
                continue
            d = tree.find(flat(c))[2]
            if d <= radius:  # Blender includes the radius itself
                dist[c] = d
    return {c: w for c, d in dist.items() if (w := falloff_weight(kind, 1 - d / radius, c, seed)) > 0}


def _round_away(v):
    return int(floor(abs(v) + 0.5)) * (1 if v >= 0 else -1)


def _deform_pass(cells, weight, axis, d):
    """Deform along one axis: every voxel moves round(weight x d). Each solid run of a
    row becomes the whole interval its moved voxels span (a continuous map sends an
    interval to an interval), so the solid stretches or compresses without tearing.
    Colours follow their voxels; stretched cells take the nearest moved colour.
    -> (cells, weights) after the pass; rows with nothing moving are untouched."""
    if d == 0:
        return cells, weight
    b, c = [i for i in range(3) if i != axis]

    def row(p):
        return p[b], p[c]

    def at(r, t):
        p = [0, 0, 0]
        p[axis], p[b], p[c] = t, r[0], r[1]
        return tuple(p)
    moving = {row(p) for p, w in weight.items() if _round_away(w * d)}
    if not moving:
        return cells, weight
    rows = {}
    out, wout = {}, {}
    for p, k in cells.items():
        if row(p) in moving:
            rows.setdefault(row(p), []).append(p[axis])
        else:
            out[p] = k
            if p in weight:
                wout[p] = weight[p]
    for r, ts in rows.items():
        ts.sort()
        runs, cur = [], [ts[0]]
        for t in ts[1:]:
            if t == cur[-1] + 1:
                cur.append(t)
            else:
                runs.append(cur)
                cur = [t]
        runs.append(cur)
        for run in runs:
            placed = {}
            for t in run:
                p = at(r, t)
                w = weight.get(p, 0.0)
                t2 = t + _round_away(w * d)
                if t2 not in placed or placed[t2][0] < w:
                    placed[t2] = (w, cells[p])
            keys = sorted(placed)
            j = 0
            for t2 in range(keys[0], keys[-1] + 1):
                while j + 1 < len(keys) and abs(keys[j + 1] - t2) < abs(keys[j] - t2):
                    j += 1
                w, k = placed[keys[j]]
                q = at(r, t2)
                if q not in wout or wout[q] < w:  # overlapping runs: the stronger one wins
                    out[q], wout[q] = k, w
                elif q not in out:
                    out[q] = k
    return out, wout


def proportional_move(cells, sel, weights, delta, stretch=True):
    """Move the selected voxels by `delta` and every weighted voxel by weight x delta
    (rounded), like Blender's proportional editing moves vertices.
    stretch=True: the model deforms as a solid, one axis of the move at a time
    (_deform_pass), so no gaps open between voxels moved by different amounts.
    stretch=False: voxels only jump to their new cell (gaps can open).
    -> ({cell: [old, new]}, new positions of the selected voxels)"""
    sel = {c for c in sel if c in cells}
    w = {c: v for c, v in weights.items() if c in cells}
    w.update({c: 1.0 for c in sel})
    new_sel = {(c[0] + delta[0], c[1] + delta[1], c[2] + delta[2]) for c in sel}
    if not any(delta) or not w:
        return {}, new_sel
    if stretch:
        cur = dict(cells)
        for axis in sorted(range(3), key=lambda i: -abs(delta[i])):
            cur, w = _deform_pass(cur, w, axis, delta[axis])
    else:
        movers = {c: tuple(_round_away(v * x) for x in delta) for c, v in w.items()}
        movers = {c: dv for c, dv in movers.items() if any(dv)}
        cur = {c: k for c, k in cells.items() if c not in movers}
        best = {}
        for c, dv in movers.items():
            t = (c[0] + dv[0], c[1] + dv[1], c[2] + dv[2])
            if t not in best or best[t][0] < w[c]:
                best[t] = (w[c], cells[c])
        cur.update({t: k for t, (_v, k) in best.items()})
    changes = {c: [cells.get(c, 0), cur.get(c, 0)] for c in set(cells) | set(cur)
               if cells.get(c, 0) != cur.get(c, 0)}
    return changes, new_sel


def plane_cell(o, d, start, axis, size):
    """Cell under the ray on the layer of `start` (for Box / Line drags), max 256 away."""
    if abs(d[axis]) < 1e-9:
        return None
    t = ((start[axis] + 0.5) * size - o[axis]) / d[axis]
    if t < 0:
        return None
    c = [floor((o[i] + d[i] * t) / size) for i in range(3)]
    c[axis] = start[axis]
    return tuple(max(start[i] - 255, min(start[i] + 255, c[i])) for i in range(3))
# ---------------------------------------------------------------- pure logic end


_drawing = False
_state = {"area": 0, "hover": None, "size": 1.0, "mode": 'ATTACH', "float": None,
          "ring_hover": None, "spin": None, "float_del": None, "prop": None,
          "rect": None, "bounds": None, "pick": False, "gizmo_hover": None, "line": None,
          "switch": None}  # session to resume (object name, "" = a new one), for the modal
# Own undo history: entries are ({cell: [old_colour, new_colour]}, voxel_size),
# colour 0 = empty. "rev" is the revision of object "obj" (name) produced by our
# own last change: while they match, the history applies (even between sessions).
_hist = {"undo": [], "redo": [], "rev": None, "obj": None}
_hist_stash = {}  # paused sessions' own undo history: object name -> (undo, redo, rev)
SESSION_SLOTS = 6  # session buttons in the viewport Session panel (all of them in the sidebar)
_sel = set()   # selected cells
_clip = {}     # copied voxels, relative to their lowest corner
MAX_HISTORY = 100
CUBE_CORNERS = np.array([(x, y, z) for z in (0, 1) for y in (0, 1) for x in (0, 1)], np.float32)
CUBE_LINES = np.array(((0, 1), (0, 2), (1, 3), (2, 3), (4, 5), (4, 6),
                       (5, 7), (6, 7), (0, 4), (1, 5), (2, 6), (3, 7)), np.int32)
MODE_KEYS = {'ONE': 'ATTACH', 'TWO': 'ERASE', 'THREE': 'MOVE', 'FOUR': 'PAINT', 'FIVE': 'SELECT'}
AXIS_KEYS = {'X': 0, 'Y': 1, 'Z': 2}
AXIS_COLORS = ((0.95, 0.25, 0.3, 1), (0.55, 0.85, 0.2, 1), (0.25, 0.55, 1, 1))
# key -> (screen axis: 0 right, 1 up, 2 toward the viewer, sign)
NUDGE = {'RIGHT_ARROW': (0, 1), 'LEFT_ARROW': (0, -1), 'UP_ARROW': (1, 1),
         'DOWN_ARROW': (1, -1), 'PAGE_UP': (2, 1), 'PAGE_DOWN': (2, -1)}
STATUS = "VoxelDraw: shortcuts in the legend / Shortcuts panel (H)    Tab: pause    Esc: exit"
LEGEND = (
    "LMB draw    Ctrl+LMB erase    RMB pick colour    Shift+RMB replace colour",
    "1-5 Attach/Erase/Move/Paint/Select    B brush    Ctrl+RMB shape    Ctrl+Wheel size    "
    "Shift+LMB rotate    Ctrl+F fill    M live mirror",
    "Select: LMB click/drag (Shift add, Ctrl remove)    A all    Alt+A none    "
    "L linked    C same colour",
    "Move: drag a gizmo arrow (axis) or its centre (free)    X / Y / Z lock the drag axis    "
    "Rotate Gizmo: drag a ring (45° steps)",
    "Selection: G move    Shift+D duplicate    R rotate    F / Shift+F flip    "
    "Arrows PgUp PgDn nudge    X delete    P paint    Ctrl+C / Ctrl+V",
    "Ctrl+Z / Ctrl+Shift+Z undo / redo    Tab pause    Esc exit    H hide legend    U viewport panels",
)


def tag_redraw_all(context):
    for win in context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def load_cells(obj):
    raw = obj.get("_vd_cells")
    if raw is None:
        return {}
    it = iter(raw.to_list())
    pos = list(zip(it, it, it))
    cols = obj.get("_vd_cols")
    return dict(zip(pos, cols.to_list() if cols is not None else [1] * len(pos)))


def save_cells(obj, cells, size):
    if cells:
        obj["_vd_cells"] = [v for c in cells for v in c]
        obj["_vd_cols"] = list(cells.values())
        obj["_vd_size"] = size
    else:
        for key in ("_vd_cells", "_vd_cols", "_vd_size"):
            obj.pop(key, None)
    rev = int(obj.get("_vd_rev", 0)) + 1
    obj["_vd_rev"] = rev
    return rev


def session_size(obj, vs):
    return float(obj["_vd_size"]) if "_vd_size" in obj else vs.voxel_size


def history_valid(obj):
    """True if the undo history ends at the voxels currently stored on obj."""
    return _hist["obj"] == obj.name and _hist["rev"] == int(obj.get("_vd_rev", 0))


def push_history(obj, changes, size, rev):
    """Record a change that took obj to revision `rev`. Older steps are dropped
    if the voxels were changed by someone else (Blender undo, other object)."""
    if not (_hist["obj"] == obj.name and _hist["rev"] == rev - 1):
        _hist["undo"].clear()
    _hist["undo"].append((changes, size))
    del _hist["undo"][:-MAX_HISTORY]
    _hist["redo"].clear()
    _hist.update(rev=rev, obj=obj.name)


def commit(scene, obj, cells, changes, size):
    """Apply {cell: [old, new]} to `cells`, store it on obj, rebuild, push undo."""
    if not changes:
        return
    for c, (_old, new) in changes.items():
        if new:
            cells[c] = new
        else:
            cells.pop(c, None)
    rebuild_mesh(obj, cells, size, palette_array(scene))
    push_history(obj, changes, size, save_cells(obj, cells, size))


def selection_action(vs, cells, action, axis=0, ccw=False, delta=(0, 0, 0)):
    """Selection commands. Updates _sel / _clip, returns the voxel changes to commit."""
    sel = {c for c in _sel if c in cells}
    if action == 'ALL':
        _sel.clear()
        _sel.update(cells)
        return {}
    if action == 'NONE':
        _sel.clear()
        return {}
    if not sel:
        return {}
    if action == 'COPY':
        lo = bounds_of(sel)[0]
        _clip.clear()
        _clip.update({(c[0] - lo[0], c[1] - lo[1], c[2] - lo[2]): cells[c] for c in sel})
        return {}
    if action == 'DELETE':
        _sel.clear()
        return {c: [cells[c], 0] for c in sel}
    if action == 'PAINT':
        k = vs.color_index
        return {c: [cells[c], k] for c in sel if cells[c] != k}
    if action == 'MIRROR':  # mirrored copy across the live mirror plane
        s = mirror_sums(vs)[axis]
        changes, moved = transform(cells, sel, lambda c: mirror_cell(c, axis, s), keep=True)
        _sel.update(moved)
        return changes
    if action == 'ROTATE':
        fn = rotate_fn(sel, axis, ccw)
    elif action == 'FLIP':
        fn = flip_fn(sel, axis)
    else:  # MOVE
        fn = lambda c: (c[0] + delta[0], c[1] + delta[1], c[2] + delta[2])  # noqa: E731
    changes, new_sel = transform(cells, sel, fn)
    _sel.clear()
    _sel.update(new_sel)
    return changes


def prop_distance(ts):
    """Blender's proportional size (scene units). 5.x shows `proportional_distance`;
    it shares its value with the older `proportional_size`."""
    return getattr(ts, "proportional_distance", None) or ts.proportional_size


def set_prop_distance(ts, v):
    v = max(1e-5, min(5000.0, v))
    if hasattr(ts, "proportional_distance"):
        ts.proportional_distance = v
    else:
        ts.proportional_size = v


def view_axes(rv3d, obj):
    """Lattice axes closest to screen right, screen up and toward the viewer: [(axis, sign)] x3."""
    inv = obj.matrix_world.to_3x3().inverted_safe()
    used, out = set(), []
    for v in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
        w = inv @ (rv3d.view_rotation @ Vector(v))
        a = max((i for i in range(3) if i not in used), key=lambda i: abs(w[i]))
        used.add(a)
        out.append((a, 1 if w[a] > 0 else -1))
    return out


def gizmo_screen(region, rv3d, obj, cells, size):
    """Move gizmo in region pixels: (centre, {axis: arrow end}) at the centre of `cells`,
    or None. Axes pointing at the viewer are hidden."""
    if not cells:
        return None
    lo, hi = bounds_of(cells)
    c_local = Vector([(lo[i] + hi[i] + 1) / 2 * size for i in range(3)])
    mw = obj.matrix_world
    c2 = location_3d_to_region_2d(region, rv3d, mw @ c_local)
    if c2 is None:
        return None
    dirs = {}
    for a in range(3):
        e = Vector((0.0, 0.0, 0.0))
        e[a] = size
        p2 = location_3d_to_region_2d(region, rv3d, mw @ (c_local + e))
        if p2 is not None:
            dirs[a] = p2 - c2
    longest = max((v.length for v in dirs.values()), default=0.0)
    if longest < 1e-6:
        return None
    px = 90 * bpy.context.preferences.system.ui_scale
    return c2, {a: c2 + v.normalized() * px for a, v in dirs.items() if v.length > 0.2 * longest}


def gizmo_hit(giz, mouse):
    """'C' (centre), an axis index, or None."""
    if giz is None:
        return None
    c2, ends = giz
    s = bpy.context.preferences.system.ui_scale
    if (mouse - c2).length < 12 * s:
        return 'C'
    best = min(ends, key=lambda a: seg_dist(mouse, c2, ends[a]), default=None)
    if best is not None and seg_dist(mouse, c2, ends[best]) < 9 * s:
        return best
    return None


def rot_gizmo_screen(region, rv3d, obj, cells, size):
    """Rotate gizmo in region pixels: (centre, {axis: closed ring points}) around the
    centre of `cells`, or None. Rings are drawn outside the move arrows."""
    if not cells:
        return None
    lo, hi = bounds_of(cells)
    c_local = Vector([(lo[i] + hi[i] + 1) / 2 * size for i in range(3)])
    mw = obj.matrix_world
    c2 = location_3d_to_region_2d(region, rv3d, mw @ c_local)
    if c2 is None:
        return None
    right = mw.to_3x3().inverted_safe() @ (rv3d.view_rotation @ Vector((1, 0, 0)))
    p2 = location_3d_to_region_2d(region, rv3d, mw @ (c_local + right.normalized()))
    if p2 is None or (p2 - c2).length < 1e-6:
        return None
    radius = 125 * bpy.context.preferences.system.ui_scale / (p2 - c2).length  # local units
    rings = {}
    for a in range(3):
        b, c = (a + 1) % 3, (a + 2) % 3
        pts = []
        for i in range(65):
            t = 2 * pi * i / 64
            p = c_local.copy()
            p[b] += radius * cos(t)
            p[c] += radius * sin(t)
            q = location_3d_to_region_2d(region, rv3d, mw @ p)
            if q is None:
                break
            pts.append(q)
        else:
            rings[a] = pts
    return c2, rings


def ring_hit(giz, mouse):
    """Axis of the gizmo ring under the mouse, or None."""
    if giz is None:
        return None
    best, dist = None, 8 * bpy.context.preferences.system.ui_scale
    for a, pts in giz[1].items():
        d = min(seg_dist(mouse, pts[i], pts[i + 1]) for i in range(len(pts) - 1))
        if d < dist:
            best, dist = a, d
    return best


def ensure_palette(vs):
    if len(vs.palette) < 2:
        set_palette(vs, default_palette())


def set_palette(vs, rgb):
    """Replace the palette (item 0 = empty voxel placeholder, hidden in the list)."""
    vs.palette.clear()
    for c in rgb:
        vs.palette.add()["color"] = c  # id-prop write: skips the update callback


def palette_array(scene):
    """(256, 3) sRGB colours by index; unused indices are grey."""
    pal = scene.voxel_settings.palette
    if len(pal) < 2:
        return np.array(default_palette(), np.float32)
    arr = np.empty(len(pal) * 3, np.float32)
    pal.foreach_get("color", arr)
    out = np.full((256, 3), 0.5, np.float32)
    out[:len(pal)] = arr.reshape(-1, 3)[:256]
    return out


def remap_removed_color(cells, k):
    """Indices above a removed palette entry k shift down by one."""
    return {c: (v - 1 if v > k else v) for c, v in cells.items()}


def fill_mesh(me, verts, faces, rgb):
    me.clear_geometry()
    nf = len(faces)
    me.vertices.add(len(verts))
    me.loops.add(nf * 4)
    me.polygons.add(nf)
    me.vertices.foreach_set("co", verts.ravel())
    me.loops.foreach_set("vertex_index", faces.ravel().astype(np.int32))
    me.polygons.foreach_set("loop_start", np.arange(0, nf * 4, 4, dtype=np.int32))
    me.update(calc_edges=True)
    me.shade_flat()
    for name in (".select_vert", ".select_edge", ".select_poly"):  # add() selects everything
        sel = me.attributes.get(name)
        if sel is not None:
            me.attributes.remove(sel)
    attr = me.color_attributes.get(COLOR_ATTR) or me.color_attributes.new(COLOR_ATTR, 'BYTE_COLOR', 'CORNER')
    rgba = np.ones((nf, 4, 4), np.float32)
    rgba[:, :, :3] = rgb[:, None, :]
    attr.data.foreach_set("color_srgb", rgba.ravel())
    me.color_attributes.active_color_name = me.color_attributes.default_color_name = COLOR_ATTR


def rebuild_mesh(obj, cells, size, pal, greedy=False):
    verts, faces, fcol = build_geometry(cells, size, greedy)
    me = obj.data
    if obj.mode != 'EDIT':
        fill_mesh(me, verts, faces, pal[fcol])
        return
    # Edit Mode: build with fast array access on a scratch mesh, then copy it in.
    tmp = bpy.data.meshes.get(TMP_MESH) or bpy.data.meshes.new(TMP_MESH)
    fill_mesh(tmp, verts, faces, pal[fcol])
    bm = bmesh.from_edit_mesh(me)
    bm.clear()
    bm.from_mesh(tmp)
    bmesh.update_edit_mesh(me)
    me.color_attributes.active_color_name = me.color_attributes.default_color_name = COLOR_ATTR


def ensure_material(obj):
    me = obj.data
    if me.materials:
        return
    mat = bpy.data.materials.get("VoxelDraw")
    if mat is None:
        mat = bpy.data.materials.new("VoxelDraw")
        nt = mat.node_tree
        attr = nt.nodes.new("ShaderNodeAttribute")
        attr.attribute_name = COLOR_ATTR
        attr.location = (-300, 300)
        nt.links.new(attr.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
    me.materials.append(mat)


def activate_object(context, obj):
    active = context.view_layer.objects.active
    if active is not None and active == obj:
        return
    if active is not None and active.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


def ensure_session_object(context):
    vs = context.scene.voxel_settings
    obj = vs.target
    if obj is not None and obj.name in context.scene.objects:
        return obj
    return new_session_object(context)


def new_session_object(context):
    """A new empty session object, made the current one (the others stay as they are)."""
    me = bpy.data.meshes.new("VoxelDraw")
    obj = bpy.data.objects.new("VoxelDraw", me)
    context.collection.objects.link(obj)
    obj["_vd_rev"] = 0
    context.scene.voxel_settings.target = obj
    forget_sessions()
    return obj


def open_sessions(scene):
    """Session objects of the scene not confirmed yet (current and paused), by name."""
    return sorted((o for o in scene.objects if o.type == 'MESH' and "_vd_rev" in o), key=lambda o: o.name)


_sessions_cache = [0.0, None, []]  # time, scene, sessions: the viewport panel asks often


def cached_sessions(scene, ttl=0.25):
    """open_sessions for the viewport panel (redrawn on every mouse move, many
    buttons ask): recomputed at most every `ttl` seconds."""
    now = time.perf_counter()
    if _sessions_cache[1] is not scene or now - _sessions_cache[0] > ttl:
        _sessions_cache[:] = [now, scene, open_sessions(scene)]
    return [o for o in _sessions_cache[2] if _alive(o, scene)]


def _alive(obj, scene):
    try:
        return obj.name in scene.objects
    except ReferenceError:  # deleted (Blender undo, X in the outliner)
        return False


def forget_sessions():
    """Sessions were added / removed: the viewport panel reads them again now."""
    _sessions_cache[0] = 0.0


def stash_history():
    """Keep the current session's undo history aside while another session runs."""
    if _hist["obj"]:
        _hist_stash[_hist["obj"]] = (_hist["undo"], _hist["redo"], _hist["rev"])


def restore_history(obj):
    """The undo history obj had when it was paused (if its voxels did not change since)."""
    undo, redo, rev = _hist_stash.pop(obj.name, ([], [], None))
    _hist.update(undo=undo, redo=redo, rev=rev, obj=obj.name)
    if not history_valid(obj):
        _hist.update(undo=[], redo=[], rev=int(obj.get("_vd_rev", 0)), obj=obj.name)


def request_session(context, name):
    """Resume session `name` ("" = start a new one). While the tool runs its modal
    does the switch (it owns strokes, history and Edit Mode); otherwise Start Voxel
    is called on it. Returns False if `name` is not an open session."""
    vs = context.scene.voxel_settings
    obj = context.scene.objects.get(name) if name else None
    if name and (obj is None or "_vd_rev" not in obj):
        return False
    if _drawing:
        _state["switch"] = name
        tag_redraw_all(context)
        return True
    if obj is not vs.target:
        stash_history()
        if obj is None:
            new_session_object(context)  # Start places its first voxel
        else:
            vs.target = obj
            restore_history(obj)
    _start_tool()
    return True


def _start_tool():
    bpy.ops.voxeldraw.start('INVOKE_DEFAULT')


def place_first_voxel(context, obj, vs):
    """Empty session: move the object so voxel (0,0,0) sits centred on the 3D cursor
    (bottom face on it along the floor normal), and add it with the active colour."""
    half = [vs.voxel_size / 2] * 3
    half[AXIS_INDEX[vs.axis]] = 0.0
    obj.location = context.scene.cursor.location - obj.matrix_world.to_3x3() @ Vector(half)
    save_cells(obj, {(0, 0, 0): vs.color_index}, vs.voxel_size)


def region_under_mouse(area, event):
    """WINDOW region under the mouse, or None if the mouse is over sidebar/toolbar/header."""
    mx, my = event.mouse_x, event.mouse_y
    window = None
    for r in area.regions:
        inside = r.x <= mx < r.x + r.width and r.y <= my < r.y + r.height
        if not inside:
            continue
        if r.type == 'WINDOW':
            window = r
        elif r.width > 1 and r.height > 1:
            return None
    return window


def pick_end(context):
    _state["pick"] = False
    context.window.cursor_modal_restore()
    context.workspace.status_text_set(STATUS)
    tag_redraw_all(context)


def _cycle(items, value):
    ids = [s[0] for s in items]
    return ids[(ids.index(value) + 1) % len(ids)]


# ---------------------------------------------------------------- properties
def _redraw(self, context):
    tag_redraw_all(context)


def refresh_session(self, context):
    """Rebuild the session mesh from the stored cells (palette changed)."""
    obj = context.scene.voxel_settings.target
    if obj is not None and "_vd_cells" in obj:
        rebuild_mesh(obj, load_cells(obj), float(obj["_vd_size"]), palette_array(context.scene))
    tag_redraw_all(context)


class VoxelColor(bpy.types.PropertyGroup):
    color: bpy.props.FloatVectorProperty(
        name="Color", subtype='COLOR_GAMMA', size=3, min=0.0, max=1.0,
        update=refresh_session)


class VoxelSettings(bpy.types.PropertyGroup):
    voxel_size: bpy.props.FloatProperty(
        name="Voxel Size", default=1.0, min=0.001, precision=3, subtype='DISTANCE',
        description="Size of the voxels of a new session (or of an empty one): "
                    "a session with voxels keeps its own size", update=_redraw)
    axis: bpy.props.EnumProperty(
        name="Floor", items=AXIS_ITEMS, default='XY', update=_redraw)
    z: bpy.props.FloatProperty(
        name="Offset", default=0.0, precision=3, subtype='DISTANCE',
        description="Floor plane offset along its normal (object space)", update=_redraw)
    show_floor: bpy.props.BoolProperty(name="Show Floor Grid", default=False, update=_redraw)
    show_bounds: bpy.props.BoolProperty(
        name="Show Bounds", default=True, update=_redraw,
        description="Draw the model bounding box (or the size limit box)")
    show_legend: bpy.props.BoolProperty(name="Show Legend", default=True, update=_redraw,
                                        description="Shortcut list (H)")
    viewport_ui: bpy.props.BoolProperty(
        name="Viewport Panels", default=True, update=_redraw,
        description="While drawing, show the tool panels inside the 3D viewport (U)")
    ui_layout: bpy.props.StringProperty(name="Viewport Panel Layout", default="", options={'HIDDEN'})
    tentacle: bpy.props.BoolProperty(
        name="Extrude Mode", default=False,
        description="Pick against the voxels changed during the same stroke: Attach "
                    "grows on what it just added (original 'tentacle' behaviour), "
                    "Erase digs through to the voxels behind")
    mode: bpy.props.EnumProperty(name="Mode", items=MODE_ITEMS, default='ATTACH', update=_redraw)
    brush: bpy.props.EnumProperty(name="Brush", items=BRUSH_ITEMS, default='SHAPE', update=_redraw,
                                  description="Brush type (B cycles)")
    shape: bpy.props.EnumProperty(
        name="Shape", items=SHAPE_ITEMS, default='POINT', update=_redraw,
        description="Brush shape (Ctrl+RMB cycles)")
    brush_size: bpy.props.IntProperty(
        name="Size", default=1, min=1, max=256, soft_max=64, update=_redraw,
        description="Brush size in voxels (Ctrl+Wheel)")
    rotation: bpy.props.IntProperty(
        name="Rotation x90°", default=0, min=0, max=3, update=_redraw,
        description="Brush rotation, clockwise (Shift+LMB)")
    fill: bpy.props.BoolProperty(name="Fill", default=False, update=_redraw,
                                 description="Filled shapes / boxes instead of outlines (Ctrl+F)")
    mirror_live: bpy.props.BoolProperty(
        name="Live Mirror", default=False, update=_redraw,
        description="While drawing, every brush (Shape, Box, Line, Face, Fill) also "
                    "builds the mirrored part (M)")
    mirror: bpy.props.BoolVectorProperty(
        name="Mirror Axes", size=3, subtype='XYZ', default=(True, False, False), update=_redraw,
        description="Axes of the live mirror. The plane goes through the first voxel "
                    "(the one spawned on the 3D cursor), or through the model centre "
                    "when Limit Model Size is on")
    prop_stretch: bpy.props.BoolProperty(
        name="Stretch", default=True, update=_redraw,
        description="Proportional editing: the model deforms as a solid, voxels moved by "
                    "different amounts stretch or squeeze the rows between them, so no gaps "
                    "open. Off: every voxel only jumps to its new cell")
    rotate_gizmo: bpy.props.BoolProperty(
        name="Rotate Gizmo", default=False, update=_redraw,
        description="Show rotation rings at the centre of the selection: drag a ring to "
                    "rotate around its axis in 45° steps. 90° steps are exact, odd 45° "
                    "steps approximate the shape (voxels can't sit at 45°)")
    move_axis: bpy.props.EnumProperty(
        name="Axis", items=MOVE_AXIS_ITEMS, default='FREE', update=_redraw,
        description="Move mode: axis used when dragging outside the gizmo arrows")
    use_limit: bpy.props.BoolProperty(
        name="Limit Model Size", default=False, update=_redraw,
        description="Only add voxels inside 0..size on each axis, like a MagicaVoxel model")
    model_size: bpy.props.IntVectorProperty(
        name="Model Size", size=3, subtype='XYZ', default=(40, 40, 40), min=1, max=256,
        update=_redraw)
    color_index: bpy.props.IntProperty(name="Color", default=1, min=1, max=255, update=_redraw)
    replace_from: bpy.props.IntProperty(name="From", default=1, min=1, max=255,
                                        description="Palette index to replace with the active colour")
    palette: bpy.props.CollectionProperty(type=VoxelColor)
    greedy: bpy.props.BoolProperty(
        name="Optimize Mesh", default=True,
        description="On Confirm, merge same-colour coplanar faces into big quads "
                    "(greedy meshing, like MagicaVoxel export; leaves T-junctions)")
    target: bpy.props.PointerProperty(type=bpy.types.Object)


# ---------------------------------------------------------------- operators
class VOXELDRAW_OT_start(bpy.types.Operator):
    bl_idname = "voxeldraw.start"
    bl_label = "Start Voxel"
    bl_description = ("Start (or resume) a voxel session and enter Edit Mode. The shortcuts "
                      "are listed in the legend at the bottom left of the viewport. "
                      "Tab to Object Mode pauses, Tab back to Edit Mode resumes")

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def invoke(self, context, event):
        global _drawing
        if _drawing:
            return {'CANCELLED'}
        vs = context.scene.voxel_settings
        ensure_palette(vs)
        obj = ensure_session_object(context)
        keep = history_valid(obj)  # e.g. Clear / Import done while no session ran
        if "_vd_cells" not in obj and not keep:  # new session (a cleared one stays undoable)
            place_first_voxel(context, obj, vs)
        ensure_material(obj)
        activate_object(context, obj)
        if obj.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
        shading = context.space_data.shading
        if shading.type == 'SOLID':
            shading.color_type = 'VERTEX'  # show the voxel colours in Solid mode
        self.stroke = self.deleting = self.dirty = False
        self.changes = {}
        self.cells, self.bounds = {}, None
        self.snapshot, self.snap_bounds = set(), None
        self.drag = self.grab = self.spin = self.sel_press = self.face_key = self.face_cells = None
        self.rev = -1
        self.size = 1.0
        self.last_build = 0.0
        self.editing = None  # forces the first mode transition
        _sel.clear()
        if not keep:
            _hist.update(undo=[], redo=[], rev=int(obj.get("_vd_rev", 0)), obj=obj.name)
        _state.update(area=context.area.as_pointer(), hover=None, size=1.0, float=None, rect=None)
        self.exit_requested = False
        start_viewport_ui(vs)
        _add_draw_handlers()
        _drawing = True
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        tag_redraw_all(context)
        return {'RUNNING_MODAL'}

    # -- helpers
    def _sync(self, obj):
        rev = int(obj.get("_vd_rev", 0))
        if rev != self.rev:  # changed by a panel button, or externally (Blender undo, reload)
            self.cells = load_cells(obj)
            self.bounds = bounds_of(self.cells)
            self.rev = rev
            self.face_key = None
            _sel.intersection_update(self.cells)
            _state["bounds"] = self.bounds
            if not history_valid(obj):  # not one of our own changes: history is stale
                _hist.update(undo=[], redo=[], rev=rev, obj=obj.name)

    def _size_for(self, obj, vs):
        if self.cells and "_vd_size" in obj:
            return float(obj["_vd_size"])
        return vs.voxel_size

    def _rebuild(self, context, obj):
        rebuild_mesh(obj, self.cells, self.size, palette_array(context.scene))

    def _commit(self, context, obj, changes):
        commit(context.scene, obj, self.cells, changes, self.size)
        self.rev = int(obj.get("_vd_rev", 0))
        self.bounds = _state["bounds"] = bounds_of(self.cells)
        self.face_key = None

    def _mode(self, vs):
        if vs.mode in ('SELECT', 'MOVE'):
            return vs.mode
        return 'ERASE' if self.deleting else vs.mode

    def _set_editing(self, context, obj, editing):
        """Edit Mode = drawing, any other mode = paused."""
        self.editing = editing
        if editing:
            self._sync(obj)
            self.size = self._size_for(obj, context.scene.voxel_settings)
            self._rebuild(context, obj)  # cells are the source of truth
            _state["bounds"] = self.bounds
            msg = STATUS
        else:
            _state["hover"] = None
            msg = "VoxelDraw paused    Tab: back to Edit Mode to resume"
        context.workspace.status_text_set(msg)
        tag_redraw_all(context)

    def _ray(self, region, event, obj):
        pos = (event.mouse_x - region.x, event.mouse_y - region.y)
        rv3d = region.data
        origin = region_2d_to_origin_3d(region, rv3d, pos)
        direction = region_2d_to_vector_3d(region, rv3d, pos)
        inv = obj.matrix_world.inverted_safe()
        return inv @ origin, inv.to_3x3() @ direction

    def _hit(self, o, d):
        if not self.cells:
            return None
        return raycast_cells(o, d, self.cells, self.bounds, self.size)

    def _brush_cells(self, vs, mode, o, d):
        """Cells the brush would affect under the ray (the preview), or None."""
        if mode == 'MOVE':
            return None
        cells = self._stroke_cells(vs, mode, o, d)
        if not cells or mode == 'SELECT':
            return cells
        return mirrored(vs, cells)

    def _stroke_cells(self, vs, mode, o, d):
        """_brush_cells without the live mirror."""
        brush = vs.brush
        if mode == 'SELECT' or brush == 'FILL':
            hit = self._hit(o, d)
            return [hit[0]] if hit else None
        if brush == 'FACE':
            hit = self._hit(o, d)
            if hit is None:
                return None
            if (hit, mode) != self.face_key:
                cell, n = hit
                reg = face_region(self.cells, cell, n)
                if mode == 'ATTACH':
                    reg = [(c[0] + n[0], c[1] + n[1], c[2] + n[2]) for c in reg]
                self.face_key, self.face_cells = (hit, mode), list(reg)
            return self.face_cells
        if self.drag:
            start, axis = self.drag
            end = plane_cell(o, d, start, axis, self.size)
            if end is None:
                return _state["hover"]
            return line_cells(start, end) if brush == 'LINE' else box_cells(start, end, axis, vs.fill)
        else:
            # During a stroke pick against the voxels as they were at the click: Attach
            # doesn't climb on what it just added, Erase doesn't dig into what was behind
            snap = self.stroke and mode in ('ATTACH', 'ERASE') and not vs.tentacle
            pool, bnds = (self.snapshot, self.snap_bounds) if snap else (self.cells, self.bounds)
            hit = pick_cell(o, d, pool, bnds, self.size, AXIS_INDEX[vs.axis], vs.z, mode != 'ATTACH')
            if hit is None:
                return None
            if brush in ('BOX', 'LINE'):
                return [hit[0]]
            return stamp_cells(*hit, vs.shape, vs.brush_size, vs.rotation, vs.fill)

    def _set_hover(self, context, cells, mode):
        if cells != _state["hover"] or self.size != _state["size"] or mode != _state["mode"]:
            _state.update(hover=cells, size=self.size, mode=mode)
            context.area.tag_redraw()

    def _apply(self, context, obj, vs, cells, mode):
        color = vs.color_index
        lim = tuple(vs.model_size) if vs.use_limit else None
        changed = False
        for cell in cells:
            old = self.cells.get(cell, 0)
            new = 0 if mode == 'ERASE' else color
            if old == new or (mode == 'ATTACH' and old) or (mode == 'PAINT' and not old):
                continue
            if lim and not old and not all(0 <= cell[i] < lim[i] for i in range(3)):
                continue
            self.changes.setdefault(cell, [old, new])[1] = new
            if new:
                self.cells[cell] = new
                self.bounds = grow(self.bounds, cell)
            else:
                del self.cells[cell]
            changed = True
        if not changed:
            return
        self.dirty = True
        self.face_key = None
        _state["bounds"] = self.bounds
        now = time.monotonic()
        if now - self.last_build > 0.03:  # throttle rebuilds during fast drags
            self._rebuild(context, obj)
            self.last_build = now

    def _step(self, context, region, event, obj, vs, deleting):
        o, d = self._ray(region, event, obj)
        mode = vs.mode if vs.mode in ('SELECT', 'MOVE') else ('ERASE' if deleting else vs.mode)
        ring = None
        if vs.rotate_gizmo and _sel and not self.stroke:
            ring = ring_hit(rot_gizmo_screen(region, region.data, obj, _sel, self.size),
                            Vector((event.mouse_x - region.x, event.mouse_y - region.y)))
        if ring != _state["ring_hover"]:
            _state["ring_hover"] = ring
            context.area.tag_redraw()
        if ring is not None:  # a click here rotates: no brush preview
            self._set_hover(context, None, mode)
            return
        if mode == 'MOVE':  # highlight the gizmo part under the mouse
            h = gizmo_hit(gizmo_screen(region, region.data, obj, _sel, self.size),
                          Vector((event.mouse_x - region.x, event.mouse_y - region.y)))
            if h != _state["gizmo_hover"]:
                _state["gizmo_hover"] = h
                context.area.tag_redraw()
        cells = self._brush_cells(vs, mode, o, d)
        self._set_hover(context, cells, mode)
        if self.stroke and cells and vs.brush == 'SHAPE' and mode != 'SELECT':
            self._apply(context, obj, vs, cells, mode)

    def _end_stroke(self, context, obj):
        self.stroke = False
        self.drag = None
        if not self.dirty:
            return
        self.dirty = False
        self._rebuild(context, obj)
        self.rev = save_cells(obj, self.cells, self.size)
        push_history(obj, self.changes, self.size, self.rev)

    def _history(self, context, obj, redo):
        self._sync(obj)
        src, dst = (_hist["redo"], _hist["undo"]) if redo else (_hist["undo"], _hist["redo"])
        if not src:
            return
        changes, size = src.pop()
        for cell, (old, new) in changes.items():
            v = new if redo else old
            if v:
                self.cells[cell] = v
            else:
                self.cells.pop(cell, None)
        dst.append((changes, size))
        self.bounds = _state["bounds"] = bounds_of(self.cells)
        self.size = size
        self.face_key = None
        _sel.intersection_update(self.cells)
        self._rebuild(context, obj)
        self.rev = save_cells(obj, self.cells, size)
        _hist["rev"] = self.rev
        context.area.tag_redraw()

    # -- mouse press / select
    def _press(self, context, region, event, obj, vs):
        self._sync(obj)
        self.size = self._size_for(obj, vs)
        if vs.rotate_gizmo and _sel:
            axis = ring_hit(rot_gizmo_screen(region, region.data, obj, _sel, self.size),
                            Vector((event.mouse_x - region.x, event.mouse_y - region.y)))
            if axis is not None:
                self._spin_start(context, region, event, obj, axis)
                return
        if vs.mode == 'SELECT':
            op = 'ADD' if event.shift else 'SUB' if event.ctrl else 'SET'
            self.sel_press = (event.mouse_x - region.x, event.mouse_y - region.y, op, region)
            return
        if vs.mode == 'MOVE':  # arrow = that axis, centre = free, elsewhere = the panel axis
            floating = {c: self.cells[c] for c in _sel if c in self.cells}
            if floating:
                h = gizmo_hit(gizmo_screen(region, region.data, obj, floating, self.size),
                              Vector((event.mouse_x - region.x, event.mouse_y - region.y)))
                if h is None and vs.move_axis != 'FREE':
                    h = 'XYZ'.index(vs.move_axis)
                self._grab_start(context, region, event, obj, floating, set(floating),
                                 line=h if isinstance(h, int) else None, drag=True)
            return
        self.deleting = event.ctrl
        self.changes = {}
        self.snapshot, self.snap_bounds = set(self.cells), self.bounds
        self.stroke = True
        mode = self._mode(vs)
        o, d = self._ray(region, event, obj)
        if vs.brush in ('BOX', 'LINE'):
            self.drag = pick_cell(o, d, self.cells, self.bounds, self.size,
                                  AXIS_INDEX[vs.axis], vs.z, mode != 'ATTACH')
            self._step(context, region, event, obj, vs, self.deleting)
        elif vs.brush == 'FILL':
            hit = self._hit(o, d)
            if hit:
                region_cells = set()
                for start in mirrored(vs, [hit[0]]):
                    if start in self.cells and start not in region_cells:
                        region_cells |= flood(self.cells, start, same_color=True)
                self._apply(context, obj, vs, region_cells, 'ERASE' if mode == 'ERASE' else 'PAINT')
        elif vs.brush == 'FACE':
            cells = self._brush_cells(vs, mode, o, d)
            if cells:
                self._apply(context, obj, vs, cells, mode)
        else:
            self._step(context, region, event, obj, vs, self.deleting)

    def _select_end(self, context, event, obj):
        x0, y0, op, region = self.sel_press
        self.sel_press = None
        _state["rect"] = None
        self._sync(obj)
        x1, y1 = event.mouse_x - region.x, event.mouse_y - region.y
        if abs(x1 - x0) + abs(y1 - y0) > 4:
            mvp = region.data.perspective_matrix @ obj.matrix_world
            picked = cells_in_rect(self.cells, mvp, self.size, region.width, region.height,
                                   (x0, y0, x1, y1))
        else:
            hit = self._hit(*self._ray(region, event, obj))
            picked = {hit[0]} if hit else set()
        if op == 'SET':
            _sel.clear()
        if op == 'SUB':
            _sel.difference_update(picked)
        else:
            _sel.update(picked)
        tag_redraw_all(context)

    # -- grab (move / duplicate / paste)
    def _grab_start(self, context, region, event, obj, floating, remove, line=None, drag=False):
        """Float voxels with the mouse. line = axis lock; drag = confirm on LMB release."""
        if not floating:
            return
        a = view_axes(region.data, obj)[2][0]
        lo, hi = bounds_of(floating)
        centre = [(lo[i] + hi[i] + 1) / 2 * self.size for i in range(3)]
        self.grab = {"float": floating, "remove": remove, "axis": a, "plane": centre[a],
                     "centre": centre, "line": line, "drag": drag,
                     "start": None, "move": [0, 0, 0], "nudge": [0, 0, 0], "delta": (0, 0, 0),
                     "prop": None, "result": None}
        _state.update(hover=None, line=line)
        if remove:  # moving voxels (not a paste / duplicate): Blender's proportional editing
            self._prop_setup(context, region, obj)
        self._grab_update(region, event, obj)
        context.workspace.status_text_set(
            ("Move: drag    release: confirm" if drag else
             "Move: mouse, Arrows, PgUp / PgDn    LMB / Enter: confirm") + "    RMB / Esc: cancel"
            + "    O: proportional    Wheel: proportional size")
        tag_redraw_all(context)

    def _grab_update(self, region, event, obj):
        g = self.grab
        if region is not None and g["line"] is not None:
            o, d = self._ray(region, event, obj)
            s = ray_axis_param(o, d, g["centre"], g["line"])
            if s is not None:
                if g["start"] is None:
                    g["start"] = s
                g["move"] = [0, 0, 0]
                g["move"][g["line"]] = floor((s - g["start"]) / self.size + 0.5)
        elif region is not None:
            o, d = self._ray(region, event, obj)
            a = g["axis"]
            if abs(d[a]) > 1e-9:
                t = (g["plane"] - o[a]) / d[a]
                p = [o[i] + d[i] * t for i in range(3)]
                if g["start"] is None:
                    g["start"] = p
                g["move"] = [0 if i == a else floor((p[i] - g["start"][i]) / self.size + 0.5)
                             for i in range(3)]
        dx = g["delta"] = tuple(g["move"][i] + g["nudge"][i] for i in range(3))
        if g["prop"] is not None:
            p = g["prop"]
            g["result"] = proportional_move(self.cells, set(g["float"]), p["weights"], dx, p["stretch"])
            changes = g["result"][0]
            _state["float"] = [c for c, (_o, n) in changes.items() if n] or list(g["float"])
            _state["float_del"] = [c for c, (_o, n) in changes.items() if not n]
        else:
            _state["float"] = [(c[0] + dx[0], c[1] + dx[1], c[2] + dx[2]) for c in g["float"]]
            _state["float_del"] = None

    def _prop_setup(self, context, region, obj):
        """(Re)compute the proportional weights of the grab from Blender's settings."""
        g = self.grab
        g["prop"] = _state["prop"] = None
        ts = context.scene.tool_settings
        if not ts.use_proportional_edit:
            return
        g["prop"] = self._prop_params(context, region, obj, set(g["float"]))
        _state["prop"] = (g["centre"], g["prop"]["radius"] * self.size)

    def _prop_params(self, context, region, obj, sel):
        ts = context.scene.tool_settings
        vs = context.scene.voxel_settings
        radius = prop_distance(ts) / self.size  # Blender's size is in scene units
        view = None
        if ts.use_proportional_projected and not ts.use_proportional_connected and region is not None:
            view = tuple(obj.matrix_world.to_3x3().inverted_safe()
                         @ (region.data.view_rotation @ Vector((0, 0, 1))))
        weights = proportional_weights(self.cells, sel, radius, ts.proportional_edit_falloff,
                                       ts.use_proportional_connected, view, seed=len(sel))
        return {"weights": weights, "radius": radius, "stretch": vs.prop_stretch}

    def _grab_end(self, context, obj, ok):
        g, self.grab = self.grab, None
        _state.update(float=None, line=None, float_del=None, prop=None)
        if ok and g["prop"] is not None:
            changes, new_sel = g["result"] or ({}, set(g["float"]))
            self._commit(context, obj, changes)
            _sel.clear()
            _sel.update(new_sel)
        elif ok:
            dx = g["delta"]
            moved = {(c[0] + dx[0], c[1] + dx[1], c[2] + dx[2]): k for c, k in g["float"].items()}
            new = {c: 0 for c in g["remove"]}
            new.update(moved)
            self._commit(context, obj, {c: [self.cells.get(c, 0), k] for c, k in new.items()
                                        if self.cells.get(c, 0) != k})
            _sel.clear()
            _sel.update(moved)
        context.workspace.status_text_set(STATUS)
        tag_redraw_all(context)

    def _grab_modal(self, context, event, obj):
        t, pressed = event.type, event.value == 'PRESS'
        region = region_under_mouse(context.area, event)
        if t == 'MOUSEMOVE':
            self._grab_update(region, event, obj)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if self.grab["drag"] and t == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._grab_end(context, obj, True)
        elif pressed and t in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
            self._grab_end(context, obj, True)
        elif pressed and t in {'RIGHTMOUSE', 'ESC'}:
            self._grab_end(context, obj, False)
        elif pressed and t in NUDGE and region is not None:
            which, sign = NUDGE[t]
            a, s = view_axes(region.data, obj)[which]
            self.grab["nudge"][a] += s * sign
            self._grab_update(None, event, obj)
            context.area.tag_redraw()
        elif pressed and t == 'O' and self.grab["remove"] and not (event.ctrl or event.alt or event.shift):
            ts = context.scene.tool_settings  # Blender's own proportional toggle (O)
            ts.use_proportional_edit = not ts.use_proportional_edit
            self._prop_setup(context, region, obj)
            self._grab_update(None, event, obj)
            tag_redraw_all(context)
        elif (t in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} and self.grab["prop"] is not None
              and not (event.ctrl or event.shift or event.alt)):
            ts = context.scene.tool_settings  # like Blender: wheel resizes the proportional circle
            set_prop_distance(ts, prop_distance(ts) * (1.1 if t == 'WHEELUPMOUSE' else 1 / 1.1))
            self._prop_setup(context, region, obj)
            self._grab_update(None, event, obj)
            tag_redraw_all(context)
        elif t == 'MIDDLEMOUSE' or t.startswith(('WHEEL', 'NUMPAD', 'TRACKPAD', 'NDOF')):
            return {'PASS_THROUGH'}  # navigation keeps working
        return {'RUNNING_MODAL'}

    # -- rotate gizmo: drag a ring around the selection centre, 45 deg steps
    def _screen_angle(self, region, event, obj):
        c2 = location_3d_to_region_2d(region, region.data,
                                      obj.matrix_world @ Vector(self.spin["centre"]))
        if c2 is None:
            return None
        x, y = event.mouse_x - region.x - c2.x, event.mouse_y - region.y - c2.y
        return atan2(y, x) if x * x + y * y > 25 else None  # unstable near the centre

    def _spin_start(self, context, region, event, obj, axis):
        sel = {c: self.cells[c] for c in _sel if c in self.cells}
        if not sel:
            return
        lo, hi = bounds_of(sel)
        toward = obj.matrix_world.to_3x3().inverted_safe() @ (
            region.data.view_rotation @ Vector((0, 0, 1)))
        # screen counter-clockwise = right hand around the axis when it points at the viewer
        self.spin = {"cells": sel, "axis": axis, "result": sel, "steps": 0, "total": 0.0,
                     "sign": 1 if toward[axis] >= 0 else -1, "last": None,
                     "centre": [(lo[i] + hi[i] + 1) / 2 * self.size for i in range(3)]}
        self.spin["last"] = self._screen_angle(region, event, obj)
        _state.update(hover=None, float=list(sel), spin=(axis, 0))
        context.workspace.status_text_set(
            "Rotate: drag around the centre (45° steps)    release: confirm    RMB / Esc: cancel")
        tag_redraw_all(context)

    def _spin_update(self, region, event, obj):
        sp = self.spin
        a = self._screen_angle(region, event, obj)
        if a is None:
            return
        if sp["last"] is not None:
            sp["total"] += wrap_angle(a - sp["last"])
        sp["last"] = a
        steps = round(sp["total"] * sp["sign"] / (pi / 4))
        if steps != sp["steps"]:  # always from the original voxels: 90 deg stays exact
            sp["steps"] = steps
            sp["result"] = rotate_cells(sp["cells"], sp["axis"], steps)
            _state.update(float=list(sp["result"]), spin=(sp["axis"], steps))

    def _spin_end(self, context, obj, ok):
        sp, self.spin = self.spin, None
        _state.update(float=None, spin=None)
        if ok and sp["steps"] % 8:
            new = {c: 0 for c in sp["cells"]}
            new.update(sp["result"])
            self._commit(context, obj, {c: [self.cells.get(c, 0), k] for c, k in new.items()
                                        if self.cells.get(c, 0) != k})
            _sel.clear()
            _sel.update(sp["result"])
        context.workspace.status_text_set(STATUS)
        tag_redraw_all(context)

    def _spin_modal(self, context, event, obj):
        t = event.type
        if t == 'MOUSEMOVE':
            region = region_under_mouse(context.area, event)
            if region is not None:
                self._spin_update(region, event, obj)
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if t == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._spin_end(context, obj, True)
        elif event.value == 'PRESS' and t in {'RIGHTMOUSE', 'ESC'}:
            self._spin_end(context, obj, False)
        elif t == 'MIDDLEMOUSE' or t.startswith(('WHEEL', 'NUMPAD', 'TRACKPAD', 'NDOF')):
            return {'PASS_THROUGH'}  # navigation keeps working
        return {'RUNNING_MODAL'}

    def _paste(self, context, region, event, obj, vs):
        """Clipboard voxels follow the mouse; click to drop them."""
        if not _clip:
            return
        self._sync(obj)
        o, d = self._ray(region, event, obj)
        hit = pick_cell(o, d, self.cells, self.bounds, self.size, AXIS_INDEX[vs.axis], vs.z, False)
        b = hit[0] if hit else (0, 0, 0)
        floating = {(b[0] + c[0], b[1] + c[1], b[2] + c[2]): k for c, k in _clip.items()}
        self._grab_start(context, region, event, obj, floating, set())

    # -- keyboard
    def _key(self, context, region, event, obj, vs):
        """Keyboard shortcuts (PRESS). Returns True when handled."""
        t = event.type
        ctrl, shift, alt = event.ctrl or event.oskey, event.shift, event.alt
        if t in MODE_KEYS and not (ctrl or alt or shift):
            vs.mode = MODE_KEYS[t]
            return True
        if t == 'B' and not (ctrl or alt):
            vs.brush = _cycle(BRUSH_ITEMS, vs.brush)
            return True
        if t == 'U' and not (ctrl or alt or shift):
            vs.viewport_ui = not vs.viewport_ui
            return True
        if t == 'H' and not (ctrl or alt):
            vs.show_legend = not vs.show_legend
            return True
        if t == 'F' and ctrl:
            vs.fill = not vs.fill
            return True
        if t == 'M' and not (ctrl or alt or shift):
            vs.mirror_live = not vs.mirror_live
            return True
        if t in AXIS_KEYS and vs.mode == 'MOVE' and not (ctrl or alt or shift):
            vs.move_axis = 'FREE' if vs.move_axis == t else t
            return True
        if self.stroke or self.sel_press:
            return False
        self._sync(obj)
        self.size = self._size_for(obj, vs)
        o, d = self._ray(region, event, obj)
        if t == 'A' and not ctrl:
            selection_action(vs, self.cells, 'NONE' if alt else 'ALL')
            return True
        if t in ('L', 'C') and not (ctrl or alt):
            hit = self._hit(o, d)
            if hit:
                if not shift:
                    _sel.clear()
                if t == 'L':
                    _sel.update(flood(self.cells, hit[0]))
                else:
                    col = self.cells[hit[0]]
                    _sel.update(c for c, k in self.cells.items() if k == col)
            return True
        if t == 'C' and ctrl:
            selection_action(vs, self.cells, 'COPY')
            return True
        if t == 'V' and ctrl:
            self._paste(context, region, event, obj, vs)
            return True
        if (t == 'G' and not (ctrl or alt or shift)) or (t == 'D' and shift and not ctrl):
            floating = {c: self.cells[c] for c in _sel if c in self.cells}
            self._grab_start(context, region, event, obj, floating,
                             set() if t == 'D' else set(floating))
            return True
        axes = view_axes(region.data, obj)
        if t == 'R' and not (ctrl or alt):  # clockwise as seen on screen
            changes = selection_action(vs, self.cells, 'ROTATE', axes[2][0], ccw=axes[2][1] < 0)
        elif t == 'F' and not alt:
            changes = selection_action(vs, self.cells, 'FLIP', axes[1 if shift else 0][0])
        elif t in NUDGE and not (ctrl or alt):
            which, sign = NUDGE[t]
            a, s = axes[which]
            delta = [0, 0, 0]
            delta[a] = s * sign
            sel = {c for c in _sel if c in self.cells}
            if context.scene.tool_settings.use_proportional_edit and sel:
                p = self._prop_params(context, region, obj, sel)
                changes, new_sel = proportional_move(self.cells, sel, p["weights"], delta, p["stretch"])
                _sel.clear()
                _sel.update(new_sel)
            else:
                changes = selection_action(vs, self.cells, 'MOVE', delta=delta)
        elif t in ('DEL', 'X') and not ctrl:
            changes = selection_action(vs, self.cells, 'DELETE')
        elif t == 'P' and not ctrl:
            changes = selection_action(vs, self.cells, 'PAINT')
        else:
            return False
        self._commit(context, obj, changes)
        return True

    # -- eyedropper (palette button): next click on a voxel picks its colour
    def _pick_modal(self, context, event, obj, vs):
        t, pressed = event.type, event.value == 'PRESS'
        if pressed and t in {'RIGHTMOUSE', 'ESC'}:
            pick_end(context)
        elif pressed and t == 'LEFTMOUSE':
            region = region_under_mouse(context.area, event)
            if region is None:
                return {'PASS_THROUGH'}
            self._sync(obj)
            hit = self._hit(*self._ray(region, event, obj))
            if hit:
                vs.color_index = self.cells[hit[0]]
            pick_end(context)
        elif t in {'MOUSEMOVE', 'MIDDLEMOUSE'} or t.startswith(('WHEEL', 'NUMPAD', 'TRACKPAD', 'NDOF')):
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}

    def _finish(self, context):
        """End the tool. The cleanup at the end runs even if saving the last stroke
        fails, so no draw handler or timer is ever left behind."""
        global _drawing
        try:
            obj = context.scene.voxel_settings.target
            if _state["pick"]:
                pick_end(context)
            if self.grab is not None or self.spin is not None:
                self.grab = self.spin = None
                _state.update(float=None, spin=None)
            if self.stroke and obj is not None:
                self._end_stroke(context, obj)
        except Exception:
            traceback.print_exc()
        _drawing = False
        _state.update(hover=None, rect=None, float=None, spin=None, pick=False)
        stop_viewport_ui()
        _remove_draw_handlers()
        try:
            if self._timer is not None:
                context.window_manager.event_timer_remove(self._timer)
            if context.workspace is not None:
                context.workspace.status_text_set(None)
            tag_redraw_all(context)
        except Exception:
            traceback.print_exc()
        self._timer = None
        return {'FINISHED'}

    def _switch(self, context, old, request):
        """Pause `old` and draw on session `request` (object name, "" = a new
        session at the 3D cursor). The paused session keeps its voxels and its own
        undo history; picking it again resumes it."""
        vs = context.scene.voxel_settings
        new = context.scene.objects.get(request) if request else None
        if request and (new is None or "_vd_rev" not in new):
            return  # deleted / confirmed in the meantime
        # end what the mouse was doing, as Tab does
        if _state["pick"]:
            pick_end(context)
        if self.grab is not None:
            self._grab_end(context, old, False)
        if self.spin is not None:
            self._spin_end(context, old, False)
        if self.stroke:
            self._end_stroke(context, old)
        self.sel_press = None
        _state["rect"] = None
        if new is old:  # the current session: just resume it
            if old.mode != 'EDIT':
                activate_object(context, old)
                bpy.ops.object.mode_set(mode='EDIT')
            return
        if old.mode != 'OBJECT' and context.view_layer.objects.active == old:
            bpy.ops.object.mode_set(mode='OBJECT')
        stash_history()
        if new is None:
            new = new_session_object(context)
            place_first_voxel(context, new, vs)
        vs.target = new
        restore_history(new)
        ensure_material(new)
        activate_object(context, new)
        bpy.ops.object.mode_set(mode='EDIT')
        _sel.clear()
        self.cells, self.bounds, self.rev = {}, None, -1  # loaded from `new` below
        self.snapshot, self.snap_bounds = set(), None
        self.drag = self.face_key = self.face_cells = None
        self.editing = None  # forces the Edit Mode transition: sync + rebuild
        tag_redraw_all(context)

    def _exit(self, context):
        """Esc / Exit: stop the tool and leave Edit Mode; Start Voxel resumes."""
        obj = context.scene.voxel_settings.target
        result = self._finish(context)
        if obj is not None and obj.mode == 'EDIT' and context.view_layer.objects.active == obj:
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except RuntimeError:
                pass
        return result

    def cancel(self, context):
        """Blender stops the operator (file load, window closed)."""
        if self._timer is not None or _handles:
            self._finish(context)

    def _ui_event(self, context, event, obj):
        """Route an event to the viewport panels: 'UI', 'OVER' or None."""
        vs = context.scene.voxel_settings
        if _ui is None or not vs.viewport_ui:
            return None
        win = ui_region(context.area)
        if win is None:
            return None
        if _ui.capture is None and region_under_mouse(context.area, event) != win:
            if _ui.leave():
                context.area.tag_redraw()
            return None
        _ui.env = SimpleNamespace(context=context, event=event, region=win, obj=obj, op=self)
        try:
            used = _ui.handle(event, event.mouse_x - win.x, event.mouse_y - win.y)
        finally:
            _ui.env = None
        if _ui.redraw or _ui.changed_values:
            _ui.redraw = False
            tag_redraw_all(context)
        return used

    # -- modal
    def modal(self, context, event):
        try:
            return self._modal(context, event)
        except Exception:  # never leave a half-dead tool (handlers, timer) behind
            traceback.print_exc()
            self.report({'ERROR'}, "VoxelDraw stopped after an internal error (see the system console)")
            self._finish(context)
            return {'CANCELLED'}

    def _modal(self, context, event):
        if not _drawing:  # Confirm pressed
            return self._finish(context)
        vs = context.scene.voxel_settings
        obj = vs.target
        if obj is None:
            return self._finish(context)
        area = context.area
        if area is None or area.as_pointer() != _state["area"]:
            # Our viewport is in another workspace (wait for it) or was closed (stop)
            return {'PASS_THROUGH'} if area_exists(_state["area"]) else self._finish(context)

        if _state["switch"] is not None:  # New Session / another session picked
            request, _state["switch"] = _state["switch"], None
            self._switch(context, obj, request)
            obj = vs.target

        editing = obj.mode == 'EDIT'
        if editing != self.editing:  # Tab between Edit / Object = resume / pause
            if _state["pick"]:
                pick_end(context)
            if self.grab is not None:
                self._grab_end(context, obj, False)
            if self.spin is not None:
                self._spin_end(context, obj, False)
            if self.stroke:
                self._end_stroke(context, obj)
            self.sel_press = None
            _state["rect"] = None
            self._set_editing(context, obj, editing)
        if event.type == 'TIMER':
            if editing and _ui is not None and vs.viewport_ui and _ui.tick():
                area.tag_redraw()  # a tooltip appears
            return {'PASS_THROUGH'}
        if not editing:
            return {'PASS_THROUGH'}

        if self.grab is not None:
            return self._grab_modal(context, event, obj)
        if self.spin is not None:
            return self._spin_modal(context, event, obj)
        if _state["pick"]:
            return self._pick_modal(context, event, obj, vs)

        if not (self.stroke or self.sel_press):  # viewport panels get the mouse first
            used = self._ui_event(context, event, obj)
            if self.exit_requested:
                return self._exit(context)
            if used == 'UI':
                return {'RUNNING_MODAL'}
            if used == 'OVER':  # mouse over a panel: no brush / gizmo hover behind it
                if _state["hover"] is not None or _state["ring_hover"] is not None:
                    _state.update(hover=None, ring_hover=None, gizmo_hover=None)
                    area.tag_redraw()
                return {'PASS_THROUGH'}

        if event.type == 'ESC' and event.value == 'PRESS':
            if self.sel_press:  # cancel the box selection
                self.sel_press = _state["rect"] = None
                area.tag_redraw()
                return {'RUNNING_MODAL'}
            if not self.stroke:
                return self._exit(context)

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if self.sel_press:
                self._select_end(context, event, obj)
                return {'RUNNING_MODAL'}
            if self.stroke:
                if self.drag and _state["hover"]:
                    self._apply(context, obj, vs, _state["hover"], self._mode(vs))
                self._end_stroke(context, obj)
                return {'RUNNING_MODAL'}

        # Checked before the region test: Blender's own undo (e.g. with the mouse
        # over the sidebar) would desync the mesh from the cells.
        if (event.type == 'Z' and event.value == 'PRESS'
                and (event.ctrl or event.oskey) and not event.alt):
            if not self.stroke:
                self._history(context, obj, redo=event.shift)
            return {'RUNNING_MODAL'}

        region = region_under_mouse(context.area, event)
        if region is None:  # over sidebar/toolbar/header/other editors: let them work
            if event.type == 'MOUSEMOVE' and _state["hover"] is not None:
                _state["hover"] = None
                context.area.tag_redraw()
            return {'PASS_THROUGH'}
        if (event.type in {'LEFTMOUSE', 'MOUSEMOVE'} and not (self.stroke or self.sel_press)
                and nav_gizmo_hit(context, context.area, region,
                                  event.mouse_x - region.x, event.mouse_y - region.y)):
            # Blender's navigation gizmo (orbit, zoom, pan, camera, perspective) works as usual
            if _state["hover"] is not None:
                _state["hover"] = None
                context.area.tag_redraw()
            return {'PASS_THROUGH'}

        if (event.value == 'PRESS' and not event.type.endswith('MOUSE')
                and self._key(context, region, event, obj, vs)):
            tag_redraw_all(context)
            return {'RUNNING_MODAL'}

        brush_key = False
        if event.type == 'RIGHTMOUSE' and event.ctrl:
            if event.value == 'PRESS':
                vs.shape = _cycle(SHAPE_ITEMS, vs.shape)
            brush_key = True
        elif event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} and event.ctrl:
            step = 1 if event.type == 'WHEELUPMOUSE' else -1
            vs.brush_size = max(1, min(256, vs.brush_size + step))
            brush_key = True
        elif (event.type == 'LEFTMOUSE' and event.shift and event.value == 'PRESS'
              and not self.stroke and vs.mode not in ('SELECT', 'MOVE')):
            vs.rotation = (vs.rotation + 1) % 4
            brush_key = True
        if brush_key:
            if not self.stroke:
                self._step(context, region, event, obj, vs, False)  # refresh the preview
            tag_redraw_all(context)
            return {'RUNNING_MODAL'}

        if event.type == 'RIGHTMOUSE':  # pick colour / Shift: replace that colour everywhere
            if event.value == 'PRESS' and not self.stroke:
                self._sync(obj)
                hit = self._hit(*self._ray(region, event, obj))
                if hit:
                    src, dst = self.cells[hit[0]], vs.color_index
                    if not event.shift:
                        vs.color_index = src
                    elif src != dst:
                        self._commit(context, obj, {c: [src, dst] for c, k in self.cells.items()
                                                    if k == src})
                tag_redraw_all(context)
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.alt:  # Alt+LMB = emulated MMB navigation
                return {'PASS_THROUGH'}
            if event.value == 'PRESS':
                self._press(context, region, event, obj, vs)
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if self.sel_press:
                x0, y0, _op, r = self.sel_press
                _state["rect"] = (x0, y0, event.mouse_x - r.x, event.mouse_y - r.y)
                context.area.tag_redraw()
                return {'PASS_THROUGH'}
            self._sync(obj)
            if not self.stroke:
                self.size = self._size_for(obj, vs)
            deleting = self.deleting if self.stroke else event.ctrl
            self._step(context, region, event, obj, vs, deleting)
        return {'PASS_THROUGH'}


class _SessionOp:
    @classmethod
    def poll(cls, context):
        return context.scene.voxel_settings.target is not None


class VOXELDRAW_OT_clear(_SessionOp, bpy.types.Operator):
    bl_idname = "voxeldraw.clear"
    bl_label = "Clear"
    bl_description = "Delete all voxels of the current session (Ctrl+Z while drawing restores them)"

    def execute(self, context):
        vs = context.scene.voxel_settings
        obj = vs.target
        cells = load_cells(obj)
        commit(context.scene, obj, cells, {c: [k, 0] for c, k in cells.items()}, session_size(obj, vs))
        _sel.clear()
        tag_redraw_all(context)
        return {'FINISHED'}


class VOXELDRAW_OT_selection(_SessionOp, bpy.types.Operator):
    bl_idname = "voxeldraw.selection"
    bl_label = "Selection"
    bl_description = "Apply a command to the selected voxels"
    action: bpy.props.EnumProperty(items=[
        ("ALL", "Select All", ""), ("NONE", "Select None", ""), ("DELETE", "Delete", ""),
        ("PAINT", "Paint", "Recolour the selection with the active colour"),
        ("COPY", "Copy", ""), ("ROTATE", "Rotate 90°", ""), ("FLIP", "Flip", ""),
        ("MIRROR", "Mirror", "Mirrored copy across the plane of the first voxel")])
    axis: bpy.props.IntProperty(min=0, max=2)

    def execute(self, context):
        vs = context.scene.voxel_settings
        obj = vs.target
        cells = load_cells(obj)
        changes = selection_action(vs, cells, self.action, self.axis, ccw=True)
        commit(context.scene, obj, cells, changes, session_size(obj, vs))
        tag_redraw_all(context)
        return {'FINISHED'}


class VOXELDRAW_OT_replace_color(_SessionOp, bpy.types.Operator):
    bl_idname = "voxeldraw.replace_color"
    bl_label = "Replace"
    bl_description = "Recolour every voxel of the 'From' index with the active colour (Shift+RMB)"

    def execute(self, context):
        vs = context.scene.voxel_settings
        obj = vs.target
        src, dst = vs.replace_from, vs.color_index
        cells = load_cells(obj)
        if src != dst:
            commit(context.scene, obj, cells, {c: [src, dst] for c, k in cells.items() if k == src},
                   session_size(obj, vs))
        tag_redraw_all(context)
        return {'FINISHED'}


class VOXELDRAW_OT_eyedropper(bpy.types.Operator):
    bl_idname = "voxeldraw.eyedropper"
    bl_label = "Pick Colour"
    bl_description = "Click a voxel to make its colour the active one (also RMB while drawing)"

    @classmethod
    def poll(cls, context):
        return _drawing

    def execute(self, context):
        _state["pick"] = True
        context.window.cursor_modal_set('EYEDROPPER')
        context.workspace.status_text_set("Click a voxel to pick its colour    RMB / Esc: cancel")
        return {'FINISHED'}


class VOXELDRAW_OT_palette_add(bpy.types.Operator):
    bl_idname = "voxeldraw.palette_add"
    bl_label = "Add Colour"
    bl_description = "Add a colour at the end of the palette (copy of the active one)"

    @classmethod
    def poll(cls, context):
        return 1 < len(context.scene.voxel_settings.palette) < 256

    def execute(self, context):
        vs = context.scene.voxel_settings
        rgb = tuple(vs.palette[min(vs.color_index, len(vs.palette) - 1)].color)
        vs.palette.add()["color"] = rgb
        vs.color_index = len(vs.palette) - 1
        return {'FINISHED'}


class VOXELDRAW_OT_palette_remove(bpy.types.Operator):
    bl_idname = "voxeldraw.palette_remove"
    bl_label = "Remove Colour"
    bl_description = "Remove this colour from the palette (the following ones shift up)"
    index: bpy.props.IntProperty(min=1)

    def execute(self, context):
        vs = context.scene.voxel_settings
        k = self.index
        if not 0 < k < len(vs.palette) or len(vs.palette) <= 2:
            self.report({'ERROR'}, "The palette needs at least one colour")
            return {'CANCELLED'}
        obj = vs.target
        cells = load_cells(obj) if obj is not None else {}
        used = sum(1 for v in cells.values() if v == k)
        if used:
            self.report({'ERROR'}, f"Colour {k} is used by {used} voxels: recolour them first "
                                   "(Replace, Paint or the Fill brush)")
            return {'CANCELLED'}
        vs.palette.remove(k)
        if cells:  # indices above k shift down; old undo steps would point to the wrong colours
            rev = save_cells(obj, remap_removed_color(cells, k), session_size(obj, vs))
            _hist.update(undo=[], redo=[], rev=rev, obj=obj.name)
            refresh_session(None, context)
        new_clip = remap_removed_color(_clip, k)
        _clip.clear()
        _clip.update(new_clip)
        vs.color_index = max(1, min(vs.color_index - (vs.color_index > k), len(vs.palette) - 1))
        if vs.replace_from >= len(vs.palette):
            vs.replace_from = len(vs.palette) - 1
        tag_redraw_all(context)
        return {'FINISHED'}


class VOXELDRAW_OT_reset_palette(bpy.types.Operator):
    bl_idname = "voxeldraw.reset_palette"
    bl_label = "Default Palette"
    bl_description = "Restore the MagicaVoxel default palette"

    def execute(self, context):
        set_palette(context.scene.voxel_settings, default_palette())
        refresh_session(None, context)
        return {'FINISHED'}


class VOXELDRAW_OT_load_palette(bpy.types.Operator, ImportHelper):
    bl_idname = "voxeldraw.load_palette"
    bl_label = "Load Palette"
    bl_description = "Load the palette of a .vox file, or of an image (256 x 1 MagicaVoxel palette PNG)"
    filter_glob: bpy.props.StringProperty(default="*.vox;*.png;*.bmp;*.tga;*.jpg", options={'HIDDEN'})

    def execute(self, context):
        try:
            if self.filepath.lower().endswith(".vox"):
                with open(self.filepath, "rb") as f:
                    pal = read_vox(f.read())[1]
                if pal is None:
                    raise ValueError("The file has no palette")
            else:
                img = bpy.data.images.load(self.filepath, check_existing=False)
                px = np.empty(len(img.pixels), np.float32)
                img.pixels.foreach_get(px)
                row = px.reshape(img.size[1], img.size[0], 4)[-1, :255, :3]  # top row
                bpy.data.images.remove(img)
                pal = [(0.0, 0.0, 0.0)] + [tuple(c) for c in row.tolist()]
                pal += default_palette()[len(pal):]
        except (OSError, ValueError, RuntimeError) as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        vs = context.scene.voxel_settings
        ensure_palette(vs)
        set_palette(vs, pal)
        refresh_session(None, context)
        return {'FINISHED'}


class VOXELDRAW_OT_import_vox(bpy.types.Operator, ImportHelper):
    bl_idname = "voxeldraw.import_vox"
    bl_label = "Import .vox"
    bl_description = "Load a MagicaVoxel .vox (voxels + palette) into the session, replacing it"
    filter_glob: bpy.props.StringProperty(default="*.vox", options={'HIDDEN'})

    def execute(self, context):
        try:
            with open(self.filepath, "rb") as f:
                new, pal = read_vox(f.read())
        except (OSError, ValueError) as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        if not new:  # would silently wipe the session
            self.report({'ERROR'}, "The file contains no voxels")
            return {'CANCELLED'}
        scene = context.scene
        vs = scene.voxel_settings
        ensure_palette(vs)
        if pal is not None:
            set_palette(vs, pal)
        if vs.target is None and context.view_layer.objects.active is not None \
                and context.view_layer.objects.active.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        obj = ensure_session_object(context)
        ensure_material(obj)
        old = load_cells(obj)
        changes = {c: [old.get(c, 0), k] for c, k in new.items() if old.get(c, 0) != k}
        changes.update({c: [k, 0] for c, k in old.items() if c not in new})
        refresh_session(None, context)  # new palette on the current voxels
        commit(scene, obj, old, changes, session_size(obj, vs))
        _sel.clear()
        tag_redraw_all(context)
        self.report({'INFO'}, f"Imported {len(new)} voxels")
        return {'FINISHED'}


class VOXELDRAW_OT_export_vox(_SessionOp, bpy.types.Operator, ExportHelper):
    bl_idname = "voxeldraw.export_vox"
    bl_label = "Export .vox"
    bl_description = "Save the session as a MagicaVoxel .vox file (max 256 per axis)"
    filename_ext = ".vox"
    filter_glob: bpy.props.StringProperty(default="*.vox", options={'HIDDEN'})

    def execute(self, context):
        cells = load_cells(context.scene.voxel_settings.target)
        if not cells:
            self.report({'ERROR'}, "Nothing to export")
            return {'CANCELLED'}
        try:
            data = vox_bytes(cells, palette_array(context.scene))
            with open(self.filepath, "wb") as f:
                f.write(data)
        except (OSError, ValueError) as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Exported {len(cells)} voxels")
        return {'FINISHED'}


class VOXELDRAW_OT_reset_ui(bpy.types.Operator):
    bl_idname = "voxeldraw.reset_ui"
    bl_label = "Reset Viewport Panels"
    bl_description = "Put the viewport panels back in their default places and sizes"

    def execute(self, context):
        context.scene.voxel_settings.ui_layout = ""
        if _ui is not None:
            _ui.set_state(None)
        tag_redraw_all(context)
        return {'FINISHED'}


class VOXELDRAW_OT_confirm(_SessionOp, bpy.types.Operator):
    bl_idname = "voxeldraw.confirm"
    bl_label = "Confirm"
    bl_description = "Finish the session: bake the voxels into a single mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _drawing
        vs = context.scene.voxel_settings
        obj = vs.target
        if obj.mode != 'OBJECT' and context.view_layer.objects.active != obj:
            self.report({'ERROR'}, "Leave Edit Mode first")
            return {'CANCELLED'}  # before touching anything: the session goes on
        _drawing = False  # the modal operator notices and stops
        _hist.update(undo=[], redo=[], rev=None, obj=None)
        _hist_stash.pop(obj.name, None)
        forget_sessions()
        _sel.clear()
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        tmp = bpy.data.meshes.get(TMP_MESH)
        if tmp is not None:
            bpy.data.meshes.remove(tmp)

        cells = load_cells(obj)
        me = obj.data
        if not cells:  # nothing drawn: discard the empty session object
            bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.meshes.remove(me)
            tag_redraw_all(context)
            self.report({'INFO'}, "Nothing drawn, session discarded")
            return {'FINISHED'}

        size = float(obj.get("_vd_size", vs.voxel_size))
        rebuild_mesh(obj, cells, size, palette_array(context.scene), greedy=vs.greedy)

        for key in ("_vd_cells", "_vd_cols", "_vd_size", "_vd_rev"):
            obj.pop(key, None)
        vs.target = None
        tag_redraw_all(context)
        self.report({'INFO'}, f"Voxel mesh confirmed ({len(me.polygons)} faces)")
        return {'FINISHED'}


class VOXELDRAW_OT_pause_resume(bpy.types.Operator):
    bl_idname = "voxeldraw.pause_resume"
    bl_label = "Pause / Resume"
    bl_description = ("Pause the session (Object Mode, the viewport works as usual) or go back to "
                      "drawing on it (same as Tab)")

    @classmethod
    def poll(cls, context):
        obj = context.scene.voxel_settings.target
        return (obj is not None and obj.name in context.scene.objects
                and context.area is not None and context.area.type == 'VIEW_3D')

    def execute(self, context):
        obj = context.scene.voxel_settings.target
        if not _drawing:  # the tool was stopped (Esc / Exit): start it on this session
            _start_tool()
            return {'FINISHED'}
        if context.view_layer.objects.active != obj:
            activate_object(context, obj)
        bpy.ops.object.mode_set(mode='OBJECT' if obj.mode == 'EDIT' else 'EDIT')
        tag_redraw_all(context)
        return {'FINISHED'}


class VOXELDRAW_OT_session_new(bpy.types.Operator):
    bl_idname = "voxeldraw.session_new"
    bl_label = "New Session"
    bl_description = ("Pause the current session and start a new one at the 3D cursor. "
                      "The paused sessions stay in the Sessions list: click one to resume it")

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        request_session(context, "")
        return {'FINISHED'}


class VOXELDRAW_OT_session_resume(bpy.types.Operator):
    bl_idname = "voxeldraw.session_resume"
    bl_label = "Resume Session"
    bl_description = "Pause the current session and draw on this one (its undo history comes back too)"

    name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        if not request_session(context, self.name):
            self.report({'ERROR'}, f"'{self.name}' is not an open voxel session")
            return {'CANCELLED'}
        return {'FINISHED'}


class VOXELDRAW_OT_session_delete(bpy.types.Operator):
    bl_idname = "voxeldraw.session_delete"
    bl_label = "Delete Session"
    bl_description = "Delete this paused session and its voxels"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        vs = context.scene.voxel_settings
        obj = context.scene.objects.get(self.name)
        if obj is None or "_vd_rev" not in obj:
            self.report({'ERROR'}, f"'{self.name}' is not an open voxel session")
            return {'CANCELLED'}
        if obj is vs.target and _drawing:
            self.report({'ERROR'}, "This is the session in use: switch to another one or Exit first")
            return {'CANCELLED'}
        _hist_stash.pop(obj.name, None)
        if _hist["obj"] == obj.name:
            _hist.update(undo=[], redo=[], rev=None, obj=None)
        if vs.target is obj:
            vs.target = None
        me = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        forget_sessions()
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)
        tag_redraw_all(context)
        return {'FINISHED'}


# ---------------------------------------------------------------- UI
class VOXELDRAW_UL_palette(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # number | name (double-click to rename) | colour | X remove
        row = layout.row(align=True)
        num = row.row()
        num.ui_units_x = 1.5
        num.label(text=str(index))
        row.prop(item, "name", text="", emboss=False)
        swatch = row.row()
        swatch.ui_units_x = 3
        swatch.prop(item, "color", text="")
        row.operator("voxeldraw.palette_remove", text="", icon='X', emboss=False).index = index

    def filter_items(self, context, data, propname):
        flags = [self.bitflag_filter_item] * len(getattr(data, propname))
        if flags:
            flags[0] = 0  # index 0 = empty voxel
        return flags, []


class _Panel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VoxelDraw"


class VOXELDRAW_PT_panel(_Panel, bpy.types.Panel):
    """While drawing everything is in the viewport panels: the sidebar keeps the
    session commands (New, Pause / Resume, Clear, Confirm) and the voxel size of
    the next session."""
    bl_label = "VoxelDraw"
    bl_idname = "VOXELDRAW_PT_panel"

    def draw(self, context):
        layout = self.layout
        vs = context.scene.voxel_settings
        obj = vs.target
        open_session = obj is not None and obj.name in context.scene.objects

        col = layout.column(align=True)
        row = col.row(align=True)
        row.scale_y = 1.4
        row.operator("voxeldraw.session_new", text="New Session", icon='ADD')
        if open_session:
            drawing = _drawing and obj.mode == 'EDIT'
            row = col.row(align=True)
            row.scale_y = 1.4
            row.operator("voxeldraw.pause_resume", text="Pause" if drawing else "Resume",
                         icon='PAUSE' if drawing else 'PLAY')
            row = col.row(align=True)
            row.operator("voxeldraw.clear", text="Clear", icon='TRASH')
            row.operator("voxeldraw.confirm", text="Confirm", icon='CHECKMARK')
            layout.label(text=obj.name + ("  (drawing)" if drawing else "  (paused)"), icon='MESH_CUBE')
        sub = layout.column()
        sub.prop(vs, "voxel_size", text="Voxel Size (new session)")


class VOXELDRAW_PT_more(_Panel, bpy.types.Panel):
    """What the viewport panels cannot do: rename palette colours, reset the panels."""
    bl_label = "Palette Names & Panels"
    bl_parent_id = "VOXELDRAW_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        vs = context.scene.voxel_settings
        if len(vs.palette) >= 2:
            layout.template_list("VOXELDRAW_UL_palette", "", vs, "palette", vs, "color_index", rows=6)
            layout.operator("voxeldraw.palette_add", icon='ADD')
        row = layout.row(align=True)
        row.prop(vs, "viewport_ui")
        row.operator("voxeldraw.reset_ui", text="", icon='LOOP_BACK')


# ---------------------------------------------------------------- viewport preview
def _lines(shader, pts, color, idx=None):
    batch = batch_for_shader(shader, 'LINES', {"pos": pts}, indices=idx)
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_cubes(shader, cells, size, color):
    p = np.array(list(cells), np.float32).reshape(-1, 3)
    if len(p):
        pts = ((p[:, None, :] + CUBE_CORNERS) * size).reshape(-1, 3)
        idx = (np.arange(len(p), dtype=np.int32)[:, None, None] * 8 + CUBE_LINES).reshape(-1, 2)
        _lines(shader, pts, color, idx)


def _toward_viewer(rv3d, obj, pts, amount):
    """Move object-space points `amount` toward the viewer: a depth bias, so ghost
    edges lying on voxel edges are not half hidden by the faces next to them."""
    inv = obj.matrix_world.inverted_safe()
    if rv3d.is_perspective:
        d = np.array(inv @ rv3d.view_matrix.inverted().translation, np.float32) - pts
    else:
        d = np.broadcast_to(np.array(inv.to_3x3() @ (rv3d.view_rotation @ Vector((0, 0, 1))),
                                     np.float32), pts.shape)
    n = np.linalg.norm(d, axis=1)[:, None]
    return pts + d / np.maximum(n, 1e-9) * amount


def _draw_ghost(rv3d, obj, cells, size, color, xray=False):
    """Voxels about to be placed / erased / painted / moved: translucent fill,
    see-through hint, thick outline with a contrasting halo."""
    tris, segs = ghost_geometry(cells)
    if not len(segs):
        return
    segs = _toward_viewer(rv3d, obj, segs * size, 0.02 * size)
    flat = gpu.shader.from_builtin('UNIFORM_COLOR')
    flat.bind()
    gpu.state.depth_test_set('NONE')
    _lines(flat, segs, (*color[:3], 0.25))  # parts hidden behind voxels
    if not xray:
        gpu.state.depth_test_set('LESS_EQUAL')
    batch = batch_for_shader(flat, 'TRIS', {"pos": tris * size})
    flat.uniform_float("color", (*color[:3], 0.18))
    batch.draw(flat)

    s = bpy.context.preferences.system.ui_scale
    dark = 0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2] < 0.3
    wide = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    wide.bind()
    wide.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    batch = batch_for_shader(wide, 'LINES', {"pos": segs})
    for width, col in ((5.0, (1, 1, 1, 0.6) if dark else (0, 0, 0, 0.6)), (2.5, (*color[:3], 1))):
        wide.uniform_float("lineWidth", width * s)
        wide.uniform_float("color", col)
        batch.draw(wide)
    gpu.state.depth_test_set('LESS_EQUAL')


def _draw_box(shader, lo, hi, size, color):
    lo = np.array(lo, np.float32)
    _lines(shader, (lo + CUBE_CORNERS * (np.array(hi, np.float32) - lo)) * size, color, CUBE_LINES)


def _floor_grid(vs, size):
    """Grid lines + quad on the floor plane: over the model limit, else 64 x 64 voxels."""
    a = AXIS_INDEX[vs.axis]
    b, c = [i for i in range(3) if i != a]
    if vs.use_limit:
        (u0, u1), (v0, v1) = (0, vs.model_size[b]), (0, vs.model_size[c])
    else:
        (u0, u1), (v0, v1) = (-32, 32), (-32, 32)

    def pt(u, v):
        p = [0.0, 0.0, 0.0]
        p[a], p[b], p[c] = vs.z, u * size, v * size
        return p
    lines = [pt(u, v) for u in range(u0, u1 + 1) for v in (v0, v1)]
    lines += [pt(u, v) for v in range(v0, v1 + 1) for u in (u0, u1)]
    return lines, [pt(u0, v0), pt(u1, v0), pt(u1, v1), pt(u0, v1)]


def draw_preview():
    try:
        _draw_preview()
    except Exception:
        _draw_failed()


def _draw_preview():
    if not _drawing:
        return
    context = bpy.context
    area = context.area
    if area is None or area.as_pointer() != _state["area"]:
        return
    vs = context.scene.voxel_settings
    obj = vs.target
    if obj is None or obj.mode != 'EDIT':
        return
    size = _state["size"]
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.depth_mask_set(False)
    gpu.matrix.push()
    gpu.matrix.multiply_matrix(obj.matrix_world)
    shader.bind()

    if vs.show_floor:
        lines, quad = _floor_grid(vs, size)
        batch = batch_for_shader(shader, 'TRIS', {"pos": quad}, indices=((0, 1, 2), (2, 3, 0)))
        shader.uniform_float("color", (1, 1, 0, 0.04))
        batch.draw(shader)
        _lines(shader, lines, (1, 1, 1, 0.12))
    if vs.show_bounds:
        if vs.use_limit:
            _draw_box(shader, (0, 0, 0), tuple(vs.model_size), size, (1, 1, 1, 0.35))
        elif _state["bounds"]:
            lo, hi = _state["bounds"]
            _draw_box(shader, lo, [h + 1 for h in hi], size, (1, 1, 1, 0.2))

    for a, corners in mirror_planes(vs, _state["bounds"]):
        quad = np.array(corners, np.float32) * size
        batch = batch_for_shader(shader, 'TRIS', {"pos": quad}, indices=((0, 1, 2), (2, 3, 0)))
        shader.uniform_float("color", (*AXIS_COLORS[a][:3], 0.08))
        batch.draw(shader)
        _lines(shader, quad, (*AXIS_COLORS[a][:3], 0.6), ((0, 1), (1, 2), (2, 3), (3, 0)))

    if _sel:  # placed voxels: thin outline
        _draw_cubes(shader, _sel, size, (1, 0.55, 0, 1))
    rv3d = context.region_data
    cells = _state["hover"]
    if cells:
        if _state["mode"] == 'ERASE':
            color = (1, 0.1, 0.1, 1)
        elif _state["mode"] == 'SELECT' or vs.color_index >= len(vs.palette):
            color = (1, 1, 1, 1)
        else:
            color = (*vs.palette[vs.color_index].color, 1)
        _draw_ghost(rv3d, obj, cells, size, color)
    if _state["float_del"]:  # voxels the proportional move removes
        _draw_ghost(rv3d, obj, _state["float_del"], size, (1, 0.25, 0.2, 1), xray=True)
    if _state["float"]:  # moving voxels stay visible through the model
        _draw_ghost(rv3d, obj, _state["float"], size, (0.2, 0.9, 1, 1), xray=True)

    gpu.matrix.pop()
    gpu.state.depth_mask_set(True)
    gpu.state.depth_test_set('NONE')
    gpu.state.blend_set('NONE')


def legend_lines(vs):
    shape = f"{vs.shape.title()} {vs.brush_size}" if vs.brush == 'SHAPE' else vs.brush.title()
    mirror = "".join("XYZ"[a] for a in live_mirror_axes(vs)) or "off"
    mode = f"Move {vs.move_axis.title()}" if vs.mode == 'MOVE' else vs.mode.title()
    head = (f"{mode}  |  {shape}{'  fill' if vs.fill else ''}  |  Mirror {mirror}  |  "
            f"Colour {vs.color_index}  |  Selected {len(_sel)}")
    return (head,) + LEGEND


def _draw_gizmo(region, rv3d, obj, vs):
    """Move-mode gizmo: one arrow per axis + a centre square, in region pixels."""
    cells = _state["float"] or _sel
    giz = gizmo_screen(region, rv3d, obj, cells, _state["size"])
    if giz is None:
        return
    c2, ends = giz
    s = bpy.context.preferences.system.ui_scale
    hot = _state["line"] if _state["float"] else _state["gizmo_hover"]
    locked = None if vs.move_axis == 'FREE' else 'XYZ'.index(vs.move_axis)
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    shader.bind()

    def tris(pts, color):
        batch = batch_for_shader(shader, 'TRIS', {"pos": [(x, y, 0) for x, y in pts]})
        shader.uniform_float("color", color)
        batch.draw(shader)
    for a, e in ends.items():
        col = AXIS_COLORS[a]
        if a == hot or a == locked:
            col = tuple(min(1.0, v + 0.35) for v in col[:3]) + (1,)
        d = (e - c2).normalized()
        n = Vector((-d.y, d.x)) * (2.5 if a == hot else 1.5) * s
        p, q = c2 + d * 14 * s, e
        tris([p - n, q - n, q + n, p - n, q + n, p + n], col)
        w = Vector((-d.y, d.x)) * 7 * s
        tris([e + d * 14 * s, e - w, e + w], col)
    h = (7 if hot == 'C' else 5) * s
    c = (1, 1, 1, 1) if hot == 'C' else (0.85, 0.85, 0.85, 0.9)
    tris([(c2.x - h, c2.y - h), (c2.x + h, c2.y - h), (c2.x + h, c2.y + h),
          (c2.x - h, c2.y - h), (c2.x + h, c2.y + h), (c2.x - h, c2.y + h)], c)


def _draw_rot_gizmo(region, rv3d, obj):
    """Rotate gizmo: one ring per axis around the selection centre, region pixels."""
    giz = rot_gizmo_screen(region, rv3d, obj, _sel, _state["size"])
    if giz is None:
        return
    c2, rings = giz
    s = bpy.context.preferences.system.ui_scale
    spin = _state["spin"]
    hot = spin[0] if spin else _state["ring_hover"]
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    for a, pts in rings.items():
        col = AXIS_COLORS[a][:3]
        if a == hot:
            col = tuple(min(1.0, v + 0.35) for v in col)
        alpha = 0.3 if spin and a != hot else 1.0
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": [(p.x, p.y, 0) for p in pts]})
        shader.uniform_float("lineWidth", (4.0 if a == hot else 2.5) * s)
        shader.uniform_float("color", (*col, alpha))
        batch.draw(shader)
    if spin:
        blf.size(0, 14 * s)
        blf.color(0, 1, 1, 1, 1)
        blf.position(0, c2.x + 14 * s, c2.y + 14 * s, 0)
        blf.draw(0, f"{spin[1] * 45:+d}°")


def _draw_prop_circle(region, rv3d, obj):
    """Proportional size as a screen circle around the moved voxels, like Blender's."""
    centre, radius = _state["prop"]
    mw = obj.matrix_world
    c = Vector(centre)
    c2 = location_3d_to_region_2d(region, rv3d, mw @ c)
    right = mw.to_3x3().inverted_safe() @ (rv3d.view_rotation @ Vector((1, 0, 0)))
    p2 = location_3d_to_region_2d(region, rv3d, mw @ (c + right.normalized() * radius))
    if c2 is None or p2 is None:
        return
    r = (p2 - c2).length
    pts = [(c2.x + r * cos(2 * pi * i / 64), c2.y + r * sin(2 * pi * i / 64), 0) for i in range(65)]
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
    shader.uniform_float("lineWidth", 1.5 * bpy.context.preferences.system.ui_scale)
    shader.uniform_float("color", (1, 1, 1, 0.55))
    batch_for_shader(shader, 'LINE_STRIP', {"pos": pts}).draw(shader)


def draw_overlay():
    try:
        _draw_overlay()
    except Exception:
        _draw_failed()


def _draw_overlay():
    if not _drawing:
        return
    context = bpy.context
    area = context.area
    if area is None or area.as_pointer() != _state["area"]:
        return
    vs = context.scene.voxel_settings
    obj = vs.target
    if obj is None or obj.mode != 'EDIT':
        return
    rect = _state["rect"]
    if rect:
        x0, y0, x1, y1 = rect
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": [
            (x0, y0, 0), (x1, y0, 0), (x1, y1, 0), (x0, y1, 0), (x0, y0, 0)]})
        shader.bind()
        shader.uniform_float("color", (1, 1, 1, 0.9))
        batch.draw(shader)
    if vs.mode == 'MOVE':
        gpu.state.blend_set('ALPHA')
        _draw_gizmo(context.region, context.region_data, obj, vs)
        gpu.state.blend_set('NONE')
    if vs.rotate_gizmo and _sel:
        gpu.state.blend_set('ALPHA')
        _draw_rot_gizmo(context.region, context.region_data, obj)
        gpu.state.blend_set('NONE')
    if _state["prop"] is not None:
        gpu.state.blend_set('ALPHA')
        _draw_prop_circle(context.region, context.region_data, obj)
        gpu.state.blend_set('NONE')
    if _ui is not None and vs.viewport_ui:
        if context.region == ui_region(area):  # quad view: panels in one region only
            draw_viewport_ui(context, area, context.region)
        return
    if not vs.show_legend:
        return
    scale = context.preferences.system.ui_scale
    x = 12 * scale + sum(r.width for r in area.regions if r.type == 'TOOLS')
    blf.size(0, 11 * scale)
    blf.enable(0, blf.SHADOW)
    blf.shadow(0, 3, 0, 0, 0, 1)
    blf.shadow_offset(0, 1, -1)
    lines = legend_lines(vs)
    for i, text in enumerate(reversed(lines)):
        a = 1.0 if i == len(lines) - 1 else 0.75  # status line brighter
        blf.color(0, 1, 1, 1, a)
        blf.position(0, x, (12 + i * 15) * scale, 0)
        blf.draw(0, text)
    blf.disable(0, blf.SHADOW)


# ---------------------------------------------------------------- viewport panels (vd_ui)
# The session's panels drawn inside the viewport. They only read / write the
# scene settings and call the same operators and functions as the sidebar and
# the shortcuts, so both stay interchangeable.
_ui = None            # vd_ui.UI while a session runs
_painter = None       # vd_ui.GPUPainter, created in the first draw
_handles = []         # draw handlers of the running session
_draw_error = [False]

D, G = vd_ui.DAT, vd_ui.GLYPH
ICONS = {
    'ATTACH': D("ops.mesh.primitive_cube_add_gizmo"), 'ERASE': D("brush.gpencil_draw.erase"),
    'MOVE': D("ops.transform.translate"), 'PAINT': D("brush.generic"),
    'SELECT': D("ops.generic.select_box"),
    'SHAPE': D("brush.paint_texture.clone"), 'BOX': D("ops.gpencil.primitive_box"),
    'LINE': D("ops.gpencil.primitive_line"), 'FACE': D("ops.mesh.extrude_region_move"),
    'FILL': D("brush.paint_texture.fill"),
    'POINT': G("■"), 'SQUARE': G("□"), 'TRIANGLE': G("△"), 'HEXAGON': G("⬡"),
    'CIRCLE': G("○"), 'SPHERE': G("●"),
    'eyedropper': D("ops.paint.eyedropper_add"), 'mirror': D("ops.gpencil.edit_mirror"),
    'rotate': D("ops.transform.rotate"), 'limit': D("ops.transform.resize.cage"),
    'grid': D("ops.mesh.primitive_grid_add_gizmo"), 'extrude': D("ops.mesh.extrude_faces_move"),
    'tools': D("brush.generic"), 'scene': D("ops.generic.cursor"),
    'undo': G("↶", vd_ui.MONO), 'redo': G("↷", vd_ui.MONO), 'trash': G("🗑"),
    'confirm': G("✔"), 'exit': G("⏏"), 'add': G("+", vd_ui.MONO), 'all': G("▦"),
    'none': G("□"), 'brush': G("🖌"), 'copy': G("❐"), 'paste': G("📋"),
    'import': G("📥"), 'export': G("📤"), 'folder': G("📂", vd_ui.EMOJI),
    'reset': G("↺", vd_ui.MONO), 'keys': G("⌨"), 'flip': G("⇄", vd_ui.MONO),
    'bounds': G("⬚"), 'palette': G("🎨", vd_ui.EMOJI), 'replace': G("⇄", vd_ui.MONO),
    'selection': G("⬚"), 'session': G("⏺"),
}
SHORTCUTS = (
    ("LMB", "draw"), ("Ctrl+LMB", "erase"), ("RMB", "pick colour"),
    ("Shift+RMB", "replace colour"), ("1 - 5", "Attach Erase Move Paint Select"),
    ("B", "next brush"), ("Ctrl+RMB", "next shape"), ("Ctrl+Wheel", "brush size"),
    ("Shift+LMB", "rotate brush"), ("Ctrl+F", "fill"), ("M", "live mirror"),
    ("A / Alt+A", "select all / none"), ("L / C", "select linked / same colour"),
    ("G / Shift+D", "move / duplicate"), ("R  F  Shift+F", "rotate / flip"),
    ("Arrows PgUp PgDn", "nudge"), ("X / P", "delete / paint selection"),
    ("Ctrl+C / Ctrl+V", "copy / paste"), ("Ctrl+Z  Ctrl+Shift+Z", "undo / redo"),
    ("O", "proportional editing (Blender's)"), ("Wheel while moving", "proportional size"),
    ("Tab", "pause"), ("Esc", "exit the tool"), ("U", "viewport panels"), ("H", "this list"),
)


def _vs():
    return bpy.context.scene.voxel_settings


def _has_cells():
    obj = _vs().target
    return obj is not None and "_vd_cells" in obj


def _run(env, fn):
    """Call an operator from a panel: its errors become a warning, not a crash."""
    try:
        fn()
    except RuntimeError as e:
        env.op.report({'WARNING'}, str(e).replace("Error:", "").strip())


def _active_rgb():
    vs = _vs()
    return tuple(vs.palette[vs.color_index].color) if vs.color_index < len(vs.palette) else None


def _hsv(k):
    def get():
        rgb = _active_rgb()
        return colorsys.rgb_to_hsv(*rgb)[k] if rgb else 0.0

    def set_(v):
        vs = _vs()
        rgb = _active_rgb()
        if rgb is None:
            return
        hsv = list(colorsys.rgb_to_hsv(*rgb))
        hsv[k] = v
        vs.palette[vs.color_index].color = colorsys.hsv_to_rgb(*hsv)
    return get, set_


def build_viewport_ui():
    """Panels spread over the viewport: tools on the left, brush next to them,
    session on top, symmetry top right, palette on the right (resizable),
    selection at the bottom, scene bottom left, shortcuts bottom right."""
    B, Row, Col, L, S = vd_ui.Button, vd_ui.Row, vd_ui.Column, vd_ui.Label, vd_ui.Slider

    def radio(attr, value, text, icon=None, tip="", **kw):
        return B(text, icon=icon, tooltip=tip, active=lambda: getattr(_vs(), attr) == value,
                 on_click=lambda env: setattr(_vs(), attr, value), **kw)

    def toggle(attr, text, icon=None, tip="", **kw):
        return B(text, icon=icon, tooltip=tip, active=lambda: bool(getattr(_vs(), attr)),
                 on_click=lambda env: setattr(_vs(), attr, not getattr(_vs(), attr)), **kw)

    def axis_toggle(attr, i, **kw):
        def flip(env):
            vs = _vs()
            v = list(getattr(vs, attr))
            v[i] = not v[i]
            setattr(vs, attr, v)
        return B("XYZ"[i], active=lambda: getattr(_vs(), attr)[i], on_click=flip, **kw)

    def prop_slider(attr, text, lo, hi, idx=None, **kw):
        if idx is None:
            def get():
                return getattr(_vs(), attr)

            def set_(v):
                setattr(_vs(), attr, v)
        else:
            def get():
                return getattr(_vs(), attr)[idx]

            def set_(v):
                vs = _vs()
                arr = list(getattr(vs, attr))
                arr[idx] = v
                setattr(vs, attr, arr)
        return S(text, get, set_, lo, hi, **kw)

    def op_button(text, icon, call, tip="", **kw):
        return B(text, icon=icon, tooltip=tip, on_click=lambda env: _run(env, lambda: call(env)), **kw)

    def session_slot(i):
        """Button i of the open sessions: the current one lit, click = resume."""
        def obj():
            sessions = cached_sessions(bpy.context.scene)
            return sessions[i] if i < len(sessions) else None

        def resume(env):
            o = obj()
            if o is not None:
                request_session(env.context, o.name)
        return B(lambda: obj().name if obj() else "", active=lambda: obj() is not None and obj() == _vs().target,
                 visible=lambda: obj() is not None, on_click=resume,
                 tooltip="Resume this session (the current one is paused, voxels and undo kept)")

    def sel_op(action, axis=0):
        return lambda env: bpy.ops.voxeldraw.selection(action=action, axis=axis)

    def has_sel():
        return bool(_sel)

    shape_on = lambda: _vs().brush == 'SHAPE'  # noqa: E731

    # -- left: tools (mode + brush type)
    tools = vd_ui.Panel("tools", "Tools", Col(
        L("Mode", small=True, dim=True),
        *[radio("mode", m, label, ICONS[m], tip, align="LEFT") for m, label, tip in MODE_ITEMS],
        vd_ui.Separator(),
        L("Brush", small=True, dim=True),
        *[radio("brush", b, label, ICONS[b], tip + ("  (B cycles)" if b == 'SHAPE' else ""), align="LEFT")
          for b, label, tip in BRUSH_ITEMS],
    ), icon=ICONS['tools'], anchor=(0, 0), offset=(8, 8))

    # -- brush settings, next to the tools
    brush = vd_ui.Panel("brush", "Brush", Col(
        Row(*[radio("shape", sh, "", ICONS[sh], f"{label}  (Ctrl+RMB cycles)", enabled=shape_on)
              for sh, label, _tip in SHAPE_ITEMS], equal=True),
        prop_slider("brush_size", "Size", 1, 256, min_w=170, enabled=shape_on,
                    tooltip="Brush size in voxels (Ctrl+Wheel)"),
        prop_slider("rotation", "Rotation x90°", 0, 3, enabled=shape_on,
                    tooltip="Brush rotation, clockwise (Shift+LMB)"),
        toggle("fill", "Fill", ICONS['FILL'], "Filled shapes and boxes instead of outlines (Ctrl+F)"),
        Col(L("Move axis", small=True, dim=True),
            Row(*[radio("move_axis", a, label, tip=tip) for a, label, tip in MOVE_AXIS_ITEMS], equal=True),
            visible=lambda: _vs().mode == 'MOVE'),
    ), icon=ICONS['SHAPE'], anchor=(0, 0), offset=(150, 8))

    # -- top: session
    session = vd_ui.Panel("session", "Session", Col(
        Row(op_button("", ICONS['undo'], lambda env: env.op._history(env.context, env.obj, False),
                      "Undo (Ctrl+Z)", enabled=lambda: bool(_hist["undo"])),
            op_button("", ICONS['redo'], lambda env: env.op._history(env.context, env.obj, True),
                      "Redo (Ctrl+Shift+Z)", enabled=lambda: bool(_hist["redo"])),
            op_button("Clear", ICONS['trash'], lambda env: bpy.ops.voxeldraw.clear(),
                      "Delete every voxel (undoable)"),
            op_button("Confirm", ICONS['confirm'], lambda env: bpy.ops.voxeldraw.confirm(),
                      "Finish: bake the voxels into a single mesh"),
            toggle("greedy", "Optimize", None, "On Confirm merge same-colour coplanar faces (greedy mesh)"),
            B("Exit", icon=ICONS['exit'], tooltip="Stop the tool (Esc). The voxels stay: Start Voxel resumes",
              on_click=lambda env: setattr(env.op, "exit_requested", True))),
        Row(L("Sessions", small=True, dim=True),
            *[session_slot(i) for i in range(SESSION_SLOTS)],
            L(lambda: "+%d (sidebar)" % (len(cached_sessions(bpy.context.scene)) - SESSION_SLOTS),
              small=True, dim=True,
              visible=lambda: len(cached_sessions(bpy.context.scene)) > SESSION_SLOTS),
            op_button("New", ICONS['add'], lambda env: request_session(env.context, ""),
                      "Pause this session and start a new one at the 3D cursor")),
        L(lambda: legend_lines(_vs())[0], small=True, dim=True, align="CENTER"),
    ), icon=ICONS['session'], anchor=(0.5, 0), offset=(0, 8))

    # -- top right (left of the navigation gizmo): symmetry and size limit
    symmetry = vd_ui.Panel("symmetry", "Symmetry", Col(
        Row(toggle("mirror_live", "Live Mirror", ICONS['mirror'], "Mirror every brush stroke (M)"),
            *[axis_toggle("mirror", i, enabled=lambda: _vs().mirror_live, tooltip="Mirror axis")
              for i in range(3)]),
        toggle("use_limit", "Limit Model Size", ICONS['limit'],
               "Only add voxels inside 0..size, like a MagicaVoxel model;\nthe mirror plane moves to the model centre"),
        Row(*[prop_slider("model_size", "XYZ"[i], 1, 256, idx=i, min_w=58, enabled=lambda: _vs().use_limit)
              for i in range(3)], equal=True),
    ), icon=ICONS['mirror'], anchor=(1, 0), offset=(96, 8))

    # -- right: palette (resizable)
    def color_label():
        vs = _vs()
        i = vs.color_index
        return f"{i}  {vs.palette[i].name}" if i < len(vs.palette) else f"{i}  (missing)"

    palette = vd_ui.Panel("palette", "Palette", Col(
        Row(vd_ui.Swatch(_active_rgb, size=(34, vd_ui.ROW)),
            L(color_label, flex=True),
            op_button("", ICONS['eyedropper'], lambda env: bpy.ops.voxeldraw.eyedropper(),
                      "Pick the colour of a voxel (also RMB)"),
            op_button("", ICONS['add'], lambda env: bpy.ops.voxeldraw.palette_add(),
                      "Add a colour (copy of the active one)", enabled=lambda: len(_vs().palette) < 256),
            op_button("", ICONS['trash'],
                      lambda env: bpy.ops.voxeldraw.palette_remove(index=_vs().color_index),
                      "Remove the active colour (only if no voxel uses it)")),
        vd_ui.ColorGrid(lambda: len(_vs().palette), lambda i: _vs().palette[i].color,
                        lambda: _vs().color_index, lambda i: setattr(_vs(), "color_index", i),
                        name=lambda i: _vs().palette[i].name,
                        tooltip="Click: active colour. Wheel: scroll"),
        *[S(label, *_hsv(k), 0.0, 1.0, step=0.01, digits=2, enabled=lambda: _active_rgb() is not None,
            tooltip="Edit the active colour (rename it in the sidebar: Palette Names & Panels)")
          for k, label in enumerate(("Hue", "Saturation", "Value"))],
        Row(prop_slider("replace_from", "From", 1, 255, tooltip="Palette index to replace", flex=True),
            op_button("To Active", ICONS['replace'], lambda env: bpy.ops.voxeldraw.replace_color(),
                      "Recolour every voxel of 'From' with the active colour (Shift+RMB)")),
        Row(op_button("Default", ICONS['reset'], lambda env: bpy.ops.voxeldraw.reset_palette(),
                      "Restore the MagicaVoxel palette"),
            op_button("Load…", ICONS['folder'],
                      lambda env: bpy.ops.voxeldraw.load_palette('INVOKE_DEFAULT'),
                      "Palette from a .vox or a 256 x 1 image"), equal=True),
    ), icon=ICONS['palette'], anchor=(1, 0.5), offset=(8, 40), resizable=True,
        size=(236, 380), min_size=(170, 230))

    # -- bottom: selection
    def axis_ops(action, label, icon, tip):
        return Row(L(label, icon=icon, small=True),
                   *[op_button("XYZ"[i], None, sel_op(action, i), f"{tip} {'XYZ'[i]}", enabled=has_sel)
                     for i in range(3)])

    selection = vd_ui.Panel("selection", "Selection", Col(
        L(lambda: f"{len(_sel)} selected    clipboard {len(_clip)}", small=True, dim=True, align="CENTER"),
        Row(op_button("All", ICONS['all'], sel_op('ALL'), "Select all (A)"),
            op_button("None", ICONS['none'], sel_op('NONE'), "Select none (Alt+A)", enabled=has_sel),
            op_button("Delete", ICONS['trash'], sel_op('DELETE'), "Delete the selection (X)", enabled=has_sel),
            op_button("Paint", ICONS['brush'], sel_op('PAINT'), "Recolour with the active colour (P)",
                      enabled=has_sel),
            op_button("Copy", ICONS['copy'], sel_op('COPY'), "Copy (Ctrl+C)", enabled=has_sel),
            op_button("Paste", ICONS['paste'],
                      lambda env: env.op._paste(env.context, env.region, env.event, env.obj, _vs()),
                      "Paste: the voxels follow the mouse, click to drop (Ctrl+V)",
                      enabled=lambda: bool(_clip))),
        Row(axis_ops('MIRROR', "Mirror", ICONS['mirror'], "Mirrored copy across the live mirror plane,"),
            axis_ops('ROTATE', "Rotate", ICONS['rotate'], "Rotate 90° around"),
            axis_ops('FLIP', "Flip", ICONS['flip'], "Flip along"),
            toggle("rotate_gizmo", "Gizmo 45°", ICONS['rotate'],
                   "Rotation rings on the selection: drag a ring, 45° steps")),
        *proportional_rows(),
    ), icon=ICONS['selection'], anchor=(0.5, 1), offset=(0, 8))

    # -- bottom left: scene and files
    scene = vd_ui.Panel("scene", "Scene", Col(
        S("Voxel Size",  # the session's own size once it has voxels (the setting is for new ones)
          lambda: session_size(_vs().target, _vs()) if _has_cells() else _vs().voxel_size,
          lambda v: setattr(_vs(), "voxel_size", v), 0.001, 100.0, digits=3, log=True, min_w=170, step=0.05,
          enabled=lambda: not _has_cells(), tooltip="Locked while the session contains voxels"),
        Row(L("Floor", small=True), *[radio("axis", a, label, tip=tip) for a, label, tip in AXIS_ITEMS],
            equal=True),
        prop_slider("z", "Floor Offset", -100.0, 100.0, digits=2, step=0.5,
                    tooltip="Floor plane offset along its normal (object space)"),
        Row(toggle("show_floor", "Grid", ICONS['grid'], "Show the floor grid"),
            toggle("show_bounds", "Bounds", ICONS['bounds'], "Show the model bounds / size limit"),
            toggle("tentacle", "Extrude", ICONS['extrude'],
                   "Strokes pick what they just changed:\nAttach grows on it, Erase digs through"),
            equal=True),
        Row(op_button("Import .vox", ICONS['import'],
                      lambda env: bpy.ops.voxeldraw.import_vox('INVOKE_DEFAULT'),
                      "Load a MagicaVoxel .vox, replacing the session"),
            op_button("Export .vox", ICONS['export'],
                      lambda env: bpy.ops.voxeldraw.export_vox('INVOKE_DEFAULT'),
                      "Save the session as a MagicaVoxel .vox", enabled=_has_cells), equal=True),
    ), icon=ICONS['scene'], anchor=(0, 1), offset=(8, 8))

    # -- bottom right: shortcuts (H)
    keys = vd_ui.Panel("shortcuts", "Shortcuts", Col(
        *[Row(L(k, small=True, dim=True), L(a, small=True)) for k, a in SHORTCUTS], spacing=0,
    ), icon=ICONS['keys'], anchor=(1, 1), offset=(8, 8), collapsed=True,
        visible=lambda: _vs().show_legend)

    return vd_ui.UI([scene, keys, selection, symmetry, session, palette, brush, tools],
                    on_layout=_save_layout)


def _ts():
    return bpy.context.scene.tool_settings


def _cell_size():
    """Voxel size of the session (scene units): Blender's proportional size is in scene units."""
    vs = _vs()
    return session_size(vs.target, vs) if vs.target is not None else vs.voxel_size


FALLOFF_ITEMS = [(i.identifier, i.name) for i in
                 bpy.types.ToolSettings.bl_rna.properties["proportional_edit_falloff"].enum_items]
FALLOFF_ICONS = {k: vd_ui.CURVE(lambda x, k=k: falloff_weight(k, 1 - x, (round(x * 24), 0, 0), 7))
                 for k, _name in FALLOFF_ITEMS}


def proportional_rows():
    """Blender's proportional editing settings (the Edit Mode header ones) for moving
    selected voxels: toggle, falloff, size in voxels, Connected / Projected, Stretch."""
    B, Row, S = vd_ui.Button, vd_ui.Row, vd_ui.Slider

    def ts_toggle(attr, text, tip, enabled=True):
        return B(text, tooltip=tip, active=lambda: getattr(_ts(), attr), enabled=enabled,
                 on_click=lambda env: setattr(_ts(), attr, not getattr(_ts(), attr)))

    on = lambda: _ts().use_proportional_edit  # noqa: E731

    def size_get():
        return prop_distance(_ts()) / _cell_size()

    def size_set(v):
        set_prop_distance(_ts(), v * _cell_size())

    return (
        Row(B("Proportional", icon=None, tooltip="Blender's proportional editing (O): moving the "
              "selection (G, gizmo, arrows) also moves the voxels around it",
              active=on, on_click=lambda env: setattr(_ts(), "use_proportional_edit", not on())),
            *[B("", icon=FALLOFF_ICONS[k], tooltip=f"Falloff: {name}", enabled=on, min_w=30, icon_scale=1.15,
                active=lambda k=k: _ts().proportional_edit_falloff == k,
                on_click=lambda env, k=k: setattr(_ts(), "proportional_edit_falloff", k))
              for k, name in FALLOFF_ITEMS]),
        Row(S("Size (voxels)", size_get, size_set, 0.5, 256.0, digits=1, step=1, log=True, min_w=150,
              enabled=on, tooltip="Proportional size (wheel while moving)", flex=True),
            ts_toggle("use_proportional_connected", "Connected",
                      "Only voxels touching the selection, measured through them", on),
            ts_toggle("use_proportional_projected", "Projected",
                      "Distance measured on the screen (ignores depth)",
                      lambda: on() and not _ts().use_proportional_connected),
            B("Stretch", tooltip="Pulled voxels fill their path, pushed ones carve it\n"
              "(off: voxels only move, gaps can open)", enabled=on,
              active=lambda: _vs().prop_stretch,
              on_click=lambda env: setattr(_vs(), "prop_stretch", not _vs().prop_stretch))),
    )


def _save_layout(state):
    _vs().ui_layout = json.dumps(state, separators=(",", ":"))


def start_viewport_ui(vs):
    global _ui, _painter
    _ui, _painter = build_viewport_ui(), None
    _draw_error[0] = False
    try:
        _ui.set_state(json.loads(vs.ui_layout) if vs.ui_layout else None)
    except (ValueError, TypeError, AttributeError):
        _ui.set_state(None)


def stop_viewport_ui():
    global _ui, _painter
    if _ui is not None:
        _ui.cancel()
    _ui = _painter = None


def ui_region(area):
    """The viewport region the panels live in (quad view: the main one)."""
    if area is None or area.type != 'VIEW_3D':
        return None
    main = area.spaces.active.region_3d
    wins = [r for r in area.regions if r.type == 'WINDOW']
    return next((r for r in wins if r.data == main), wins[-1] if wins else None)


def ui_bounds(area, region):
    """(L, B, R, T) of the region not covered by the toolbar, sidebar or headers
    drawn over it (Region Overlap), in region pixels."""
    L, B, R, T = 0, 0, region.width, region.height
    for r in area.regions:
        if r.type not in {'TOOLS', 'UI', 'HEADER', 'TOOL_HEADER'} or r.width <= 1 or r.height <= 1:
            continue
        x0, x1 = max(r.x, region.x), min(r.x + r.width, region.x + region.width)
        y0, y1 = max(r.y, region.y), min(r.y + r.height, region.y + region.height)
        if x1 <= x0 or y1 <= y0:
            continue
        if r.type in {'TOOLS', 'UI'}:
            if r.x + r.width / 2 < region.x + region.width / 2:
                L = max(L, x1 - region.x)
            else:
                R = min(R, x0 - region.x)
        elif r.y + r.height / 2 > region.y + region.height / 2:
            T = min(T, y0 - region.y)
        else:
            B = max(B, y1 - region.y)
    return L, B, R, T


def nav_gizmo_hit(context, area, region, mx, my):
    """True if region pixel (mx, my) is on Blender's navigation gizmo: the orbit
    ball or the zoom / pan / camera / perspective buttons under it. Same layout as
    Blender 5.0 (view3d_gizmo_navigate.cc, WIDGETGROUP_navigate_draw_prepare)."""
    space = area.spaces.active
    if not (space.show_gizmo and space.show_gizmo_navigate):
        return False
    view, system = context.preferences.view, context.preferences.system
    ball = view.mini_axis_type == 'GIZMO'
    if not (ball or view.show_navigate_ui):
        return False
    s = system.ui_scale or 1.0
    _l, _b, right, top = ui_bounds(area, region)  # ED_region_visible_rect
    size = view.gizmo_size_navigate_v3d
    offset = (size / 2 + 10) * s  # GIZMO_SIZE / 2 + GIZMO_OFFSET
    if ball and (mx - (right - offset)) ** 2 + (my - (top - offset)) ** 2 <= (size / 2 * s) ** 2:
        return True
    if not view.show_navigate_ui:
        return False
    mini = (28 + 2) * s  # GIZMO_MINI_SIZE + GIZMO_MINI_OFFSET
    if ball:
        below = offset * 2.1
    elif view.mini_axis_type == 'MINIMAL':
        below = 20 * s * 2.5 + view.mini_axis_size * system.pixel_size * 2
    else:
        below = mini * 0.75
    x, y = round(right - mini * 0.75), round(top - below)
    # zoom, pan, camera, perspective (or camera lock): up to 4 buttons, one below the other
    return any((mx - x) ** 2 + (my - (y - mini * slot)) ** 2 <= (14 * s) ** 2 for slot in range(4))


def draw_viewport_ui(context, area, region):
    global _painter
    if _painter is None:
        _painter = vd_ui.GPUPainter()
    scale = context.preferences.system.ui_scale or 1.0
    _ui.layout(_painter, ui_bounds(area, region), scale)
    gpu.state.blend_set('ALPHA')
    try:
        _ui.draw(_painter)
    finally:
        gpu.state.blend_set('NONE')


def _draw_failed():
    """A draw callback failed: report once per session, hide the panels."""
    if not _draw_error[0]:
        _draw_error[0] = True
        traceback.print_exc()
    stop_viewport_ui()


def _add_draw_handlers():
    _remove_draw_handlers()
    _handles.append(bpy.types.SpaceView3D.draw_handler_add(draw_preview, (), 'WINDOW', 'POST_VIEW'))
    _handles.append(bpy.types.SpaceView3D.draw_handler_add(draw_overlay, (), 'WINDOW', 'POST_PIXEL'))


def _remove_draw_handlers():
    while _handles:
        h = _handles.pop()
        try:
            bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
        except (ValueError, RuntimeError, ReferenceError):
            pass


def area_exists(pointer):
    """Is the area still in some screen (maybe of another workspace)?"""
    return any(a.as_pointer() == pointer for sc in bpy.data.screens for a in sc.areas)


@persistent
def _on_load(_dummy):
    global _drawing
    _drawing = False  # modal operators do not survive a file load
    stop_viewport_ui()
    _remove_draw_handlers()
    _sel.clear()
    _hist.update(undo=[], redo=[], rev=None, obj=None)  # it belonged to the previous file
    _hist_stash.clear()
    _state["switch"] = None


classes = (
    VoxelColor,
    VoxelSettings,
    VOXELDRAW_OT_start,
    VOXELDRAW_OT_clear,
    VOXELDRAW_OT_selection,
    VOXELDRAW_OT_replace_color,
    VOXELDRAW_OT_eyedropper,
    VOXELDRAW_OT_palette_add,
    VOXELDRAW_OT_palette_remove,
    VOXELDRAW_OT_reset_palette,
    VOXELDRAW_OT_load_palette,
    VOXELDRAW_OT_import_vox,
    VOXELDRAW_OT_export_vox,
    VOXELDRAW_OT_confirm,
    VOXELDRAW_OT_pause_resume,
    VOXELDRAW_OT_session_new,
    VOXELDRAW_OT_session_resume,
    VOXELDRAW_OT_session_delete,
    VOXELDRAW_OT_reset_ui,
    VOXELDRAW_UL_palette,
    VOXELDRAW_PT_panel,
    VOXELDRAW_PT_more,
)
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.voxel_settings = bpy.props.PointerProperty(type=VoxelSettings)
    bpy.app.handlers.load_post.append(_on_load)


def unregister():
    global _drawing
    _drawing = False
    stop_viewport_ui()
    _remove_draw_handlers()  # a session still running when the add-on is disabled
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    del bpy.types.Scene.voxel_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
